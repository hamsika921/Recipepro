package com.example.planner

import com.example.data.model.DailyMealPlan
import com.example.data.model.Recipe
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

sealed class ChangeResult {
    data class Success(
        val updatedPlan: DailyMealPlan,
        val newRecipeName: String,
        val previousRecipeName: String?,
        val slot: MealSlot
    ) : ChangeResult()

    data class NoAlternatives(
        val message: String,
        val slot: MealSlot
    ) : ChangeResult()
}

object MealPlanningEngine {

    /**
     * Generates a complete monthly meal plan according to all specified rules.
     * Never fabricates recipes; only uses recipes from saved collections.
     */
    fun generateMonthPlan(
        year: Int,
        month: Int, // 1..12
        recipes: List<Recipe>
    ): List<DailyMealPlan> {
        val daysInMonth = getDaysInMonth(year, month)
        val yearMonthStr = String.format(Locale.US, "%04d-%02d", year, month)

        // Recipe usage counters across the month to distribute evenly
        val usageCount = mutableMapOf<Long, Int>()

        val plans = mutableListOf<DailyMealPlan>()
        var previousDayPlan: DailyMealPlan? = null

        for (day in 1..daysInMonth) {
            val dateIso = String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
            val dayOfWeek = getDayOfWeek(year, month, day) // "SUNDAY", "MONDAY", ...
            val isSunday = dayOfWeek.equals("SUNDAY", ignoreCase = true)
            val isSaturday = dayOfWeek.equals("SATURDAY", ignoreCase = true)

            // 1. Breakfast
            val breakfastCandidates = getEligibleCandidates(
                slot = MealSlot.BREAKFAST,
                recipes = recipes,
                isSunday = isSunday,
                isSaturday = isSaturday
            )
            val breakfast = pickBestRecipe(
                candidates = breakfastCandidates,
                usageCount = usageCount,
                recentlyUsedId = previousDayPlan?.breakfastRecipeId
            )
            breakfast?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }

            // 2. Lunch
            var lunchRice: Recipe? = null
            var lunchCurry: Recipe? = null
            var lunchFry: Recipe? = null
            var lunchBiryani: Recipe? = null

            if (isSunday) {
                // Rule 5: Sunday lunch must be Biryani
                val biryaniCandidates = getEligibleCandidates(
                    slot = MealSlot.LUNCH_BIRYANI,
                    recipes = recipes,
                    isSunday = true,
                    isSaturday = false
                )
                lunchBiryani = pickBestRecipe(
                    candidates = biryaniCandidates,
                    usageCount = usageCount,
                    recentlyUsedId = previousDayPlan?.lunchBiryaniRecipeId
                )
                lunchBiryani?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }
            } else {
                // Rule 2: Mon-Sat Lunch has Rice + Curry + Fry as three separate components
                val riceCandidates = getEligibleCandidates(
                    slot = MealSlot.LUNCH_RICE,
                    recipes = recipes,
                    isSunday = false,
                    isSaturday = isSaturday
                )
                lunchRice = pickBestRecipe(
                    candidates = riceCandidates,
                    usageCount = usageCount,
                    recentlyUsedId = previousDayPlan?.lunchRiceRecipeId
                )
                lunchRice?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }

                val curryCandidates = getEligibleCandidates(
                    slot = MealSlot.LUNCH_CURRY,
                    recipes = recipes,
                    isSunday = false,
                    isSaturday = isSaturday
                )
                lunchCurry = pickBestRecipe(
                    candidates = curryCandidates,
                    usageCount = usageCount,
                    recentlyUsedId = previousDayPlan?.lunchCurryRecipeId
                )
                lunchCurry?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }

                val fryCandidates = getEligibleCandidates(
                    slot = MealSlot.LUNCH_FRY,
                    recipes = recipes,
                    isSunday = false,
                    isSaturday = isSaturday
                )
                lunchFry = pickBestRecipe(
                    candidates = fryCandidates,
                    usageCount = usageCount,
                    recentlyUsedId = previousDayPlan?.lunchFryRecipeId
                )
                lunchFry?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }
            }

            // 3. Evening Snack
            val snackCandidates = getEligibleCandidates(
                slot = MealSlot.SNACK,
                recipes = recipes,
                isSunday = isSunday,
                isSaturday = isSaturday
            )
            val snack = pickBestRecipe(
                candidates = snackCandidates,
                usageCount = usageCount,
                recentlyUsedId = previousDayPlan?.snackRecipeId
            )
            snack?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }

            // 4. Dinner
            val dinnerCandidates = getEligibleCandidates(
                slot = MealSlot.DINNER,
                recipes = recipes,
                isSunday = isSunday,
                isSaturday = isSaturday
            )
            val dinner = pickBestRecipe(
                candidates = dinnerCandidates,
                usageCount = usageCount,
                recentlyUsedId = previousDayPlan?.dinnerRecipeId
            )
            dinner?.let { usageCount[it.id] = (usageCount[it.id] ?: 0) + 1 }

            val dailyPlan = DailyMealPlan(
                yearMonth = yearMonthStr,
                dateIso = dateIso,
                dayOfMonth = day,
                dayOfWeek = dayOfWeek,
                breakfastRecipeId = breakfast?.id,
                breakfastRecipeName = breakfast?.name,
                breakfastRecipeUrl = breakfast?.url,
                lunchType = if (isSunday) "BIRYANI" else "COMPONENTS",
                lunchRiceRecipeId = lunchRice?.id,
                lunchRiceRecipeName = lunchRice?.name,
                lunchRiceRecipeUrl = lunchRice?.url,
                lunchCurryRecipeId = lunchCurry?.id,
                lunchCurryRecipeName = lunchCurry?.name,
                lunchCurryRecipeUrl = lunchCurry?.url,
                lunchFryRecipeId = lunchFry?.id,
                lunchFryRecipeName = lunchFry?.name,
                lunchFryRecipeUrl = lunchFry?.url,
                lunchBiryaniRecipeId = lunchBiryani?.id,
                lunchBiryaniRecipeName = lunchBiryani?.name,
                lunchBiryaniRecipeUrl = lunchBiryani?.url,
                snackRecipeId = snack?.id,
                snackRecipeName = snack?.name,
                snackRecipeUrl = snack?.url,
                dinnerRecipeId = dinner?.id,
                dinnerRecipeName = dinner?.name,
                dinnerRecipeUrl = dinner?.url
            )

            plans.add(dailyPlan)
            previousDayPlan = dailyPlan
        }

        return plans
    }

    /**
     * Executes the critical Change button action for a single meal or lunch component.
     * - Replaces only the selected meal with a different suitable recipe.
     * - Keeps every other meal on that day unchanged.
     * - Preserves all meal-planning rules (Saturday vegetarian, Sunday Biryani, Sunday-only items, etc.).
     * - Does NOT regenerate the entire month.
     * - Does NOT replace with the same recipe currently displayed.
     * - Avoids choosing another recipe that already appears too frequently in the monthly plan.
     */
    fun changeMeal(
        currentPlan: DailyMealPlan,
        slot: MealSlot,
        allRecipes: List<Recipe>,
        monthPlans: List<DailyMealPlan>,
        forcedReplacementRecipe: Recipe? = null
    ): ChangeResult {
        val isSunday = currentPlan.dayOfWeek.equals("SUNDAY", ignoreCase = true)
        val isSaturday = currentPlan.dayOfWeek.equals("SATURDAY", ignoreCase = true)

        val currentRecipeId = when (slot) {
            MealSlot.BREAKFAST -> currentPlan.breakfastRecipeId
            MealSlot.LUNCH_RICE -> currentPlan.lunchRiceRecipeId
            MealSlot.LUNCH_CURRY -> currentPlan.lunchCurryRecipeId
            MealSlot.LUNCH_FRY -> currentPlan.lunchFryRecipeId
            MealSlot.LUNCH_BIRYANI -> currentPlan.lunchBiryaniRecipeId
            MealSlot.SNACK -> currentPlan.snackRecipeId
            MealSlot.DINNER -> currentPlan.dinnerRecipeId
        }

        val previousRecipeName = when (slot) {
            MealSlot.BREAKFAST -> currentPlan.breakfastRecipeName
            MealSlot.LUNCH_RICE -> currentPlan.lunchRiceRecipeName
            MealSlot.LUNCH_CURRY -> currentPlan.lunchCurryRecipeName
            MealSlot.LUNCH_FRY -> currentPlan.lunchFryRecipeName
            MealSlot.LUNCH_BIRYANI -> currentPlan.lunchBiryaniRecipeName
            MealSlot.SNACK -> currentPlan.snackRecipeName
            MealSlot.DINNER -> currentPlan.dinnerRecipeName
        }

        val chosenRecipe: Recipe = if (forcedReplacementRecipe != null) {
            forcedReplacementRecipe
        } else {
            // Find eligible alternative candidates
            val alternatives = getEligibleAlternatives(
                slot = slot,
                recipes = allRecipes,
                isSunday = isSunday,
                isSaturday = isSaturday,
                currentRecipeId = currentRecipeId,
                monthPlans = monthPlans
            )

            if (alternatives.isEmpty()) {
                return ChangeResult.NoAlternatives(
                    message = "No alternative recipes available. Add more recipes to this collection.",
                    slot = slot
                )
            }

            // Pick the best candidate (lowest frequency in current month, randomized if tie)
            alternatives.first()
        }

        // Apply change ONLY to this slot, keeping all other meals unchanged
        val updatedPlan = when (slot) {
            MealSlot.BREAKFAST -> currentPlan.copy(
                breakfastRecipeId = chosenRecipe.id,
                breakfastRecipeName = chosenRecipe.name,
                breakfastRecipeUrl = chosenRecipe.url
            )
            MealSlot.LUNCH_RICE -> currentPlan.copy(
                lunchRiceRecipeId = chosenRecipe.id,
                lunchRiceRecipeName = chosenRecipe.name,
                lunchRiceRecipeUrl = chosenRecipe.url
            )
            MealSlot.LUNCH_CURRY -> currentPlan.copy(
                lunchCurryRecipeId = chosenRecipe.id,
                lunchCurryRecipeName = chosenRecipe.name,
                lunchCurryRecipeUrl = chosenRecipe.url
            )
            MealSlot.LUNCH_FRY -> currentPlan.copy(
                lunchFryRecipeId = chosenRecipe.id,
                lunchFryRecipeName = chosenRecipe.name,
                lunchFryRecipeUrl = chosenRecipe.url
            )
            MealSlot.LUNCH_BIRYANI -> currentPlan.copy(
                lunchBiryaniRecipeId = chosenRecipe.id,
                lunchBiryaniRecipeName = chosenRecipe.name,
                lunchBiryaniRecipeUrl = chosenRecipe.url
            )
            MealSlot.SNACK -> currentPlan.copy(
                snackRecipeId = chosenRecipe.id,
                snackRecipeName = chosenRecipe.name,
                snackRecipeUrl = chosenRecipe.url
            )
            MealSlot.DINNER -> currentPlan.copy(
                dinnerRecipeId = chosenRecipe.id,
                dinnerRecipeName = chosenRecipe.name,
                dinnerRecipeUrl = chosenRecipe.url
            )
        }

        return ChangeResult.Success(
            updatedPlan = updatedPlan,
            newRecipeName = chosenRecipe.name,
            previousRecipeName = previousRecipeName,
            slot = slot
        )
    }

    /**
     * Gets all valid alternative candidates for a slot, sorted by ascending frequency in month.
     * Excludes the current recipe.
     */
    fun getEligibleAlternatives(
        slot: MealSlot,
        recipes: List<Recipe>,
        isSunday: Boolean,
        isSaturday: Boolean,
        currentRecipeId: Long?,
        monthPlans: List<DailyMealPlan>
    ): List<Recipe> {
        val eligible = getEligibleCandidates(slot, recipes, isSunday, isSaturday)
            .filter { it.id != currentRecipeId }

        if (eligible.isEmpty()) return emptyList()

        // Calculate occurrence counts of each recipe across the month
        val frequencyMap = mutableMapOf<Long, Int>()
        for (plan in monthPlans) {
            plan.breakfastRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            plan.lunchRiceRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            plan.lunchCurryRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            plan.lunchFryRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            plan.lunchBiryaniRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            plan.snackRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            plan.dinnerRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
        }

        // Sort by frequency ascending, then shuffle equals to provide variety
        return eligible.shuffled(Random(System.currentTimeMillis()))
            .sortedBy { frequencyMap[it.id] ?: 0 }
    }

    /**
     * Filters all saved recipes to those matching rules for this specific slot.
     */
    fun getEligibleCandidates(
        slot: MealSlot,
        recipes: List<Recipe>,
        isSunday: Boolean,
        isSaturday: Boolean
    ): List<Recipe> {
        val targetCollections = when (slot) {
            MealSlot.BREAKFAST -> {
                if (isSunday) {
                    MealPlanningConfig.BREAKFAST_COLLECTIONS
                } else {
                    MealPlanningConfig.BREAKFAST_COLLECTIONS - MealPlanningConfig.SUNDAY_ONLY_COLLECTIONS
                }
            }
            MealSlot.LUNCH_RICE -> MealPlanningConfig.LUNCH_RICE_COLLECTIONS
            MealSlot.LUNCH_CURRY -> MealPlanningConfig.LUNCH_CURRY_COLLECTIONS
            MealSlot.LUNCH_FRY -> MealPlanningConfig.LUNCH_FRY_COLLECTIONS
            MealSlot.LUNCH_BIRYANI -> MealPlanningConfig.SUNDAY_LUNCH_COLLECTIONS
            MealSlot.SNACK -> {
                if (isSunday) {
                    MealPlanningConfig.BASE_SNACK_COLLECTIONS + MealPlanningConfig.SUNDAY_ONLY_COLLECTIONS
                } else {
                    MealPlanningConfig.BASE_SNACK_COLLECTIONS
                }
            }
            MealSlot.DINNER -> {
                if (isSunday) {
                    MealPlanningConfig.DINNER_COLLECTIONS
                } else {
                    MealPlanningConfig.DINNER_COLLECTIONS - MealPlanningConfig.SUNDAY_ONLY_COLLECTIONS
                }
            }
        }

        return recipes.filter { recipe ->
            // Must belong to target collections
            if (recipe.collectionName !in targetCollections) return@filter false

            // Rule 8 & 9: Global exclusion check
            if (MealPlanningConfig.isRecipeGloballyExcluded(recipe.collectionName, recipe.name)) return@filter false

            // Rule 7: Sunday only constraint
            if (!isSunday && recipe.collectionName in MealPlanningConfig.SUNDAY_ONLY_COLLECTIONS) return@filter false

            // Rule 6: Saturday must be vegetarian
            if (isSaturday && !MealPlanningConfig.isVegetarian(recipe.collectionName, recipe.name)) return@filter false

            true
        }
    }

    /**
     * Picks the recipe with the lowest monthly usage count. Avoids repeating yesterday's recipe if alternatives exist.
     */
    private fun pickBestRecipe(
        candidates: List<Recipe>,
        usageCount: Map<Long, Int>,
        recentlyUsedId: Long?
    ): Recipe? {
        if (candidates.isEmpty()) return null
        if (candidates.size == 1) return candidates.first()

        // Filter out recently used recipe if we have alternatives
        val pool = if (candidates.size > 1 && recentlyUsedId != null) {
            candidates.filter { it.id != recentlyUsedId }.ifEmpty { candidates }
        } else {
            candidates
        }

        // Find min usage count
        val minUsage = pool.minOf { usageCount[it.id] ?: 0 }
        val leastUsed = pool.filter { (usageCount[it.id] ?: 0) == minUsage }

        return leastUsed.random(Random(System.currentTimeMillis()))
    }

    /**
     * Requirement 6: The Change button on a daily meal plan must regenerate
     * the entire selected day's plan, including breakfast, lunch components,
     * evening snack, and dinner. It must not modify any other day.
     * Respects all applicable planning restrictions and saves immediately.
     */
    fun regenerateEntireDayPlan(
        currentPlan: DailyMealPlan,
        allRecipes: List<Recipe>,
        monthPlans: List<DailyMealPlan>
    ): DailyMealPlan {
        val isSunday = currentPlan.dayOfWeek.equals("SUNDAY", ignoreCase = true)
        val isSaturday = currentPlan.dayOfWeek.equals("SATURDAY", ignoreCase = true)

        // Frequency map across month excluding current day
        val frequencyMap = mutableMapOf<Long, Int>()
        for (plan in monthPlans) {
            if (plan.dateIso != currentPlan.dateIso) {
                plan.breakfastRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
                plan.lunchRiceRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
                plan.lunchCurryRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
                plan.lunchFryRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
                plan.lunchBiryaniRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
                plan.snackRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
                plan.dinnerRecipeId?.let { frequencyMap[it] = (frequencyMap[it] ?: 0) + 1 }
            }
        }

        // 1. Breakfast
        val breakfastCandidates = getEligibleCandidates(MealSlot.BREAKFAST, allRecipes, isSunday, isSaturday)
        val breakfast = pickAlternativeRecipe(breakfastCandidates, currentPlan.breakfastRecipeId, frequencyMap)

        // 2. Lunch
        var lunchRice: Recipe? = null
        var lunchCurry: Recipe? = null
        var lunchFry: Recipe? = null
        var lunchBiryani: Recipe? = null

        if (isSunday) {
            val biryaniCandidates = getEligibleCandidates(MealSlot.LUNCH_BIRYANI, allRecipes, isSunday = true, isSaturday = false)
            lunchBiryani = pickAlternativeRecipe(biryaniCandidates, currentPlan.lunchBiryaniRecipeId, frequencyMap)
        } else {
            val riceCandidates = getEligibleCandidates(MealSlot.LUNCH_RICE, allRecipes, isSunday = false, isSaturday = isSaturday)
            lunchRice = pickAlternativeRecipe(riceCandidates, currentPlan.lunchRiceRecipeId, frequencyMap)

            val curryCandidates = getEligibleCandidates(MealSlot.LUNCH_CURRY, allRecipes, isSunday = false, isSaturday = isSaturday)
            lunchCurry = pickAlternativeRecipe(curryCandidates, currentPlan.lunchCurryRecipeId, frequencyMap)

            val fryCandidates = getEligibleCandidates(MealSlot.LUNCH_FRY, allRecipes, isSunday = false, isSaturday = isSaturday)
            lunchFry = pickAlternativeRecipe(fryCandidates, currentPlan.lunchFryRecipeId, frequencyMap)
        }

        // 3. Evening Snack
        val snackCandidates = getEligibleCandidates(MealSlot.SNACK, allRecipes, isSunday, isSaturday)
        val snack = pickAlternativeRecipe(snackCandidates, currentPlan.snackRecipeId, frequencyMap)

        // 4. Dinner
        val dinnerCandidates = getEligibleCandidates(MealSlot.DINNER, allRecipes, isSunday, isSaturday)
        val dinner = pickAlternativeRecipe(dinnerCandidates, currentPlan.dinnerRecipeId, frequencyMap)

        return currentPlan.copy(
            breakfastRecipeId = breakfast?.id,
            breakfastRecipeName = breakfast?.name,
            breakfastRecipeUrl = breakfast?.url,
            lunchType = if (isSunday) "BIRYANI" else "COMPONENTS",
            lunchRiceRecipeId = lunchRice?.id,
            lunchRiceRecipeName = lunchRice?.name,
            lunchRiceRecipeUrl = lunchRice?.url,
            lunchCurryRecipeId = lunchCurry?.id,
            lunchCurryRecipeName = lunchCurry?.name,
            lunchCurryRecipeUrl = lunchCurry?.url,
            lunchFryRecipeId = lunchFry?.id,
            lunchFryRecipeName = lunchFry?.name,
            lunchFryRecipeUrl = lunchFry?.url,
            lunchBiryaniRecipeId = lunchBiryani?.id,
            lunchBiryaniRecipeName = lunchBiryani?.name,
            lunchBiryaniRecipeUrl = lunchBiryani?.url,
            snackRecipeId = snack?.id,
            snackRecipeName = snack?.name,
            snackRecipeUrl = snack?.url,
            dinnerRecipeId = dinner?.id,
            dinnerRecipeName = dinner?.name,
            dinnerRecipeUrl = dinner?.url
        )
    }

    private fun pickAlternativeRecipe(
        candidates: List<Recipe>,
        currentId: Long?,
        frequencyMap: Map<Long, Int>
    ): Recipe? {
        if (candidates.isEmpty()) return null
        val pool = if (candidates.size > 1 && currentId != null) {
            candidates.filter { it.id != currentId }.ifEmpty { candidates }
        } else {
            candidates
        }
        val minFreq = pool.minOf { frequencyMap[it.id] ?: 0 }
        val leastUsed = pool.filter { (frequencyMap[it.id] ?: 0) == minFreq }
        return leastUsed.random(Random(System.currentTimeMillis()))
    }

    fun getDaysInMonth(year: Int, month: Int): Int {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun getDayOfWeek(year: Int, month: Int, day: Int): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1)
        cal.set(Calendar.DAY_OF_MONTH, day)
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SUNDAY -> "SUNDAY"
            Calendar.MONDAY -> "MONDAY"
            Calendar.TUESDAY -> "TUESDAY"
            Calendar.WEDNESDAY -> "WEDNESDAY"
            Calendar.THURSDAY -> "THURSDAY"
            Calendar.FRIDAY -> "FRIDAY"
            Calendar.SATURDAY -> "SATURDAY"
            else -> "MONDAY"
        }
    }
}
