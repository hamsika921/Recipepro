package com.example.planner

enum class MealSlot(val displayName: String) {
    BREAKFAST("Breakfast"),
    LUNCH_RICE("Rice (Lunch)"),
    LUNCH_CURRY("Curry (Lunch)"),
    LUNCH_FRY("Fry (Lunch)"),
    LUNCH_BIRYANI("Biryani (Sunday Lunch)"),
    SNACK("Evening Snack"),
    DINNER("Dinner")
}
