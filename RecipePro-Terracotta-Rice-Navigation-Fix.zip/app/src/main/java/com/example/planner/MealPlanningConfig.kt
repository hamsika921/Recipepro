package com.example.planner

/**
 * Centralized, configurable meal planning rules and collections.
 * Contains the EXACT 27 predefined collections and 8 Junk categories.
 */
object MealPlanningConfig {

    // EXACT 27 predefined collections in specified order
    val PREDEFINED_COLLECTIONS = listOf(
        "Chilla / Dosa / Paratha",
        "Rice",
        "Biryani",
        "Pasta",
        "Sandwich / Burgers",
        "Tacos / Shawarma",
        "Fry",
        "Curry",
        "Chips / Potato Rolls",
        "Pizza",
        "Soup",
        "Cakes",
        "Momo / Punugulu / Bajji",
        "Bread",
        "Noodles",
        "Mixtures",
        "Chocolate",
        "Pancakes",
        "Dips",
        "Chutney",
        "Paneer",
        "Soya",
        "Chicken",
        "Sweets",
        "Cookies / Biscuits",
        "Juice",
        "Ice Cream"
    )

    // The 8 Junk navigation categories
    val JUNK_CATEGORIES = listOf(
        "Bread",
        "Mixtures",
        "Cakes",
        "Cookies / Biscuits",
        "Chocolate",
        "Juice",
        "Ice Cream",
        "Sweets"
    )

    // Rule 7: Sunday-only collections in regular meal planner
    val SUNDAY_ONLY_COLLECTIONS = setOf(
        "Bread",
        "Mixtures",
        "Cakes",
        "Cookies / Biscuits",
        "Chocolate"
    )

    // Rule 1: Breakfast collections
    // Note: "Bread" is only eligible if day is Sunday
    val BREAKFAST_COLLECTIONS = setOf(
        "Chilla / Dosa / Paratha",
        "Pancakes",
        "Bread"
    )

    // Rule 2: Lunch components
    val LUNCH_RICE_COLLECTIONS = setOf("Rice")
    val LUNCH_CURRY_COLLECTIONS = setOf("Curry")
    val LUNCH_FRY_COLLECTIONS = setOf("Fry")

    // Rule 5: Sunday lunch collection
    val SUNDAY_LUNCH_COLLECTIONS = setOf("Biryani")

    // Rule 4: Evening snack collections
    val BASE_SNACK_COLLECTIONS = setOf(
        "Momo / Punugulu / Bajji",
        "Chips / Potato Rolls",
        "Sandwich / Burgers",
        "Tacos / Shawarma",
        "Noodles",
        "Soup",
        "Pasta",
        "Dips",
        "Chutney",
        "Paneer",
        "Soya"
    )

    // Rule 3: Dinner collections
    val DINNER_COLLECTIONS = setOf(
        "Chilla / Dosa / Paratha",
        "Pasta",
        "Sandwich / Burgers",
        "Tacos / Shawarma",
        "Pizza",
        "Noodles",
        "Soup",
        "Paneer",
        "Soya"
    )

    // Rule 8: Exclude Chicken collections from meal planner
    val EXCLUDED_COLLECTION_KEYWORDS = setOf(
        "chicken"
    )

    // Rule: Exclude Juice, Ice Cream, and Sweets from regular meal plans (available in Junk only)
    val EXCLUDED_PLANNER_COLLECTIONS = setOf(
        "juice",
        "ice cream",
        "sweets"
    )

    // Excluded food keywords
    val EXCLUDED_FOOD_KEYWORDS = setOf(
        "drink", "drinks", "juice", "juices", "ice cream", "icecream", "sweet", "sweets", "mithai"
    )

    // Rule 6: Saturday Vegetarian check keywords (non-veg indicators)
    val NON_VEGETARIAN_KEYWORDS = setOf(
        "chicken", "mutton", "fish", "prawn", "prawns", "egg", "eggs", "meat", "beef", "pork",
        "keema", "bacon", "salmon", "shrimp", "shrimps", "crab", "ham", "turkey", "lamb", "duck", "sausage"
    )

    /**
     * Checks if a recipe is excluded from regular meal planner:
     * - Chicken collections
     * - Juice, Ice Cream, Sweets
     */
    fun isRecipeGloballyExcluded(collectionName: String, recipeName: String): Boolean {
        val colLower = collectionName.lowercase()
        val nameLower = recipeName.lowercase()

        // Exclude Chicken
        if (EXCLUDED_COLLECTION_KEYWORDS.any { colLower.contains(it) || nameLower.contains(it) }) return true

        // Exclude Juice, Ice Cream, and Sweets from regular meal planner
        if (EXCLUDED_PLANNER_COLLECTIONS.any { colLower == it }) return true

        // Exclude general drinks / ice cream / juices keywords
        if (EXCLUDED_FOOD_KEYWORDS.any { colLower.contains(it) || nameLower.contains(it) }) return true

        return false
    }

    /**
     * Checks if recipe satisfies Saturday Vegetarian rule.
     */
    fun isVegetarian(collectionName: String, recipeName: String): Boolean {
        val colLower = collectionName.lowercase()
        val nameLower = recipeName.lowercase()

        return !NON_VEGETARIAN_KEYWORDS.any { kw ->
            colLower.contains(kw) || nameLower.contains(kw)
        }
    }
}
