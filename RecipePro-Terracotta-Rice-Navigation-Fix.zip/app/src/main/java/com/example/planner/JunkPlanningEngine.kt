package com.example.planner

import com.example.data.model.DailyJunkPlan
import com.example.data.model.Recipe
import kotlin.random.Random

object JunkPlanningEngine {

    /**
     * Requirement 4: Each day, generate one random recipe from each of the eight
     * Junk categories (Bread, Mixtures, Cakes, Cookies / Biscuits, Chocolate,
     * Juice, Ice Cream, Sweets) if recipes are available.
     * Never generates fake recipes or duplicates a recipe within the same day's selections.
     */
    fun generateDailyJunkPlan(
        dateIso: String,
        allRecipes: List<Recipe>,
        currentPlan: DailyJunkPlan? = null
    ): DailyJunkPlan {
        val usedRecipeIds = mutableSetOf<Long>()

        fun pickCategoryRecipe(collectionName: String, currentId: Long?): Recipe? {
            val candidates = allRecipes.filter { it.collectionName.equals(collectionName, ignoreCase = true) }
            if (candidates.isEmpty()) return null

            val availableCandidates = candidates.filter { it.id !in usedRecipeIds }
            val pool = if (availableCandidates.size > 1 && currentId != null) {
                availableCandidates.filter { it.id != currentId }.ifEmpty { availableCandidates }
            } else {
                availableCandidates.ifEmpty { candidates }
            }

            val chosen = pool.random(Random(System.currentTimeMillis()))
            usedRecipeIds.add(chosen.id)
            return chosen
        }

        val bread = pickCategoryRecipe("Bread", currentPlan?.breadRecipeId)
        val mixtures = pickCategoryRecipe("Mixtures", currentPlan?.mixturesRecipeId)
        val cakes = pickCategoryRecipe("Cakes", currentPlan?.cakesRecipeId)
        val cookies = pickCategoryRecipe("Cookies / Biscuits", currentPlan?.cookiesRecipeId)
        val chocolate = pickCategoryRecipe("Chocolate", currentPlan?.chocolateRecipeId)
        val juice = pickCategoryRecipe("Juice", currentPlan?.juiceRecipeId)
        val iceCream = pickCategoryRecipe("Ice Cream", currentPlan?.iceCreamRecipeId)
        val sweets = pickCategoryRecipe("Sweets", currentPlan?.sweetsRecipeId)

        return DailyJunkPlan(
            dateIso = dateIso,
            breadRecipeId = bread?.id,
            breadRecipeName = bread?.name,
            breadRecipeUrl = bread?.url,
            mixturesRecipeId = mixtures?.id,
            mixturesRecipeName = mixtures?.name,
            mixturesRecipeUrl = mixtures?.url,
            cakesRecipeId = cakes?.id,
            cakesRecipeName = cakes?.name,
            cakesRecipeUrl = cakes?.url,
            cookiesRecipeId = cookies?.id,
            cookiesRecipeName = cookies?.name,
            cookiesRecipeUrl = cookies?.url,
            chocolateRecipeId = chocolate?.id,
            chocolateRecipeName = chocolate?.name,
            chocolateRecipeUrl = chocolate?.url,
            juiceRecipeId = juice?.id,
            juiceRecipeName = juice?.name,
            juiceRecipeUrl = juice?.url,
            iceCreamRecipeId = iceCream?.id,
            iceCreamRecipeName = iceCream?.name,
            iceCreamRecipeUrl = iceCream?.url,
            sweetsRecipeId = sweets?.id,
            sweetsRecipeName = sweets?.name,
            sweetsRecipeUrl = sweets?.url,
            updatedAt = System.currentTimeMillis()
        )
    }
}
