package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.ViewDay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.DailyMealPlan
import com.example.planner.MealSlot
import com.example.ui.components.MealSlotItem
import com.example.ui.viewmodel.RecipeProViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyPlannerScreen(
    viewModel: RecipeProViewModel,
    modifier: Modifier = Modifier
) {
    val selectedYear by viewModel.selectedYear.collectAsState()
    val selectedMonth by viewModel.selectedMonth.collectAsState()
    val selectedDay by viewModel.selectedDay.collectAsState()
    val monthPlans by viewModel.currentMonthPlans.collectAsState()

    var showRegenerateDialog by remember { mutableStateOf(false) }
    var viewMode by remember { mutableStateOf(0) } // 0 = Single Day Focus, 1 = Full Month List

    val daysListState = rememberLazyListState()

    // Scroll day strip to selected day when changed
    LaunchedEffect(selectedDay) {
        if (selectedDay > 0 && selectedDay <= monthPlans.size) {
            daysListState.animateScrollToItem((selectedDay - 1).coerceAtLeast(0))
        }
    }

    val currentPlan = monthPlans.find { it.dayOfMonth == selectedDay }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Month Selector & Actions Header
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("month_selector_header")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.previousMonth() },
                    modifier = Modifier.testTag("prev_month_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Month"
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { viewModel.goToCurrentMonth() }
                ) {
                    Text(
                        text = "${viewModel.getMonthName(selectedMonth)} $selectedYear",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Tap to jump to Current Month",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.nextMonth() },
                        modifier = Modifier.testTag("next_month_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next Month"
                        )
                    }

                    IconButton(
                        onClick = { showRegenerateDialog = true },
                        modifier = Modifier.testTag("regenerate_month_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Autorenew,
                            contentDescription = "Regenerate Month",
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // View Mode Switcher: "Day Focus" vs "Full Month List"
        TabRow(
            selectedTabIndex = viewMode,
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
        ) {
            Tab(
                selected = viewMode == 0,
                onClick = { viewMode = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ViewDay, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Day Focus")
                    }
                }
            )
            Tab(
                selected = viewMode == 1,
                onClick = { viewMode = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.ViewAgenda, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("All Days (${monthPlans.size})")
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Horizontal Date Strip (1..31)
        LazyRow(
            state = daysListState,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("horizontal_days_strip")
        ) {
            items(monthPlans, key = { it.id }) { plan ->
                val isSelected = plan.dayOfMonth == selectedDay
                val isSunday = plan.dayOfWeek.equals("SUNDAY", ignoreCase = true)
                val isSaturday = plan.dayOfWeek.equals("SATURDAY", ignoreCase = true)

                Surface(
                    onClick = {
                        viewModel.selectDay(plan.dayOfMonth)
                        viewMode = 0 // Switch to day focus when tapping day chip
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.primary
                    } else if (isSunday) {
                        MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f)
                    } else if (isSaturday) {
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f)
                    } else {
                        MaterialTheme.colorScheme.surface
                    },
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .width(64.dp)
                        .testTag("day_chip_${plan.dayOfMonth}")
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = plan.dayOfWeek.take(3),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${plan.dayOfMonth}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        if (isSunday) {
                            Text(
                                text = "Biryani",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = androidx.compose.ui.unit.TextUnit(9f, androidx.compose.ui.unit.TextUnitType.Sp),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.tertiary
                            )
                        } else if (isSaturday) {
                            Text(
                                text = "Veg",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = androidx.compose.ui.unit.TextUnit(9f, androidx.compose.ui.unit.TextUnitType.Sp),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.secondary
                            )
                        } else {
                            Text(
                                text = "Rice+2",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = androidx.compose.ui.unit.TextUnit(9f, androidx.compose.ui.unit.TextUnitType.Sp),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content: Either Single Day Focus or Full Month List
        if (viewMode == 0) {
            // Day Focus View
            if (currentPlan != null) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        DayHeaderInfo(
                            plan = currentPlan,
                            onChangeDayPlan = { viewModel.onRegenerateEntireDayPlan(currentPlan) }
                        )
                    }

                    // 1. Breakfast
                    item {
                        MealSlotItem(
                            slot = MealSlot.BREAKFAST,
                            recipeName = currentPlan.breakfastRecipeName,
                            recipeUrl = currentPlan.breakfastRecipeUrl,
                            onChangeClicked = { viewModel.onSlotChangeClicked(currentPlan, MealSlot.BREAKFAST) },
                            onBrowseAlternatives = { viewModel.openSlotAlternativePicker(currentPlan, MealSlot.BREAKFAST) },
                            modifier = Modifier.testTag("day_focus_breakfast")
                        )
                    }

                    // 2. Lunch
                    item {
                        LunchCardSection(
                            plan = currentPlan,
                            onSlotChange = { slot -> viewModel.onSlotChangeClicked(currentPlan, slot) },
                            onBrowseAlternatives = { slot -> viewModel.openSlotAlternativePicker(currentPlan, slot) }
                        )
                    }

                    // 3. Evening Snack
                    item {
                        MealSlotItem(
                            slot = MealSlot.SNACK,
                            recipeName = currentPlan.snackRecipeName,
                            recipeUrl = currentPlan.snackRecipeUrl,
                            onChangeClicked = { viewModel.onSlotChangeClicked(currentPlan, MealSlot.SNACK) },
                            onBrowseAlternatives = { viewModel.openSlotAlternativePicker(currentPlan, MealSlot.SNACK) },
                            modifier = Modifier.testTag("day_focus_snack")
                        )
                    }

                    // 4. Dinner
                    item {
                        MealSlotItem(
                            slot = MealSlot.DINNER,
                            recipeName = currentPlan.dinnerRecipeName,
                            recipeUrl = currentPlan.dinnerRecipeUrl,
                            onChangeClicked = { viewModel.onSlotChangeClicked(currentPlan, MealSlot.DINNER) },
                            onBrowseAlternatives = { viewModel.openSlotAlternativePicker(currentPlan, MealSlot.DINNER) },
                            modifier = Modifier.testTag("day_focus_dinner")
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Select a date above to view meals.")
                }
            }
        } else {
            // Full Month List View
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(monthPlans, key = { it.id }) { plan ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("month_plan_day_${plan.dayOfMonth}")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            DayHeaderInfo(
                                plan = plan,
                                onChangeDayPlan = { viewModel.onRegenerateEntireDayPlan(plan) }
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            // Breakfast
                            MealSlotItem(
                                slot = MealSlot.BREAKFAST,
                                recipeName = plan.breakfastRecipeName,
                                recipeUrl = plan.breakfastRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(plan, MealSlot.BREAKFAST) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(plan, MealSlot.BREAKFAST) }
                            )

                            // Lunch
                            LunchCardSection(
                                plan = plan,
                                onSlotChange = { slot -> viewModel.onSlotChangeClicked(plan, slot) },
                                onBrowseAlternatives = { slot -> viewModel.openSlotAlternativePicker(plan, slot) }
                            )

                            // Snack
                            MealSlotItem(
                                slot = MealSlot.SNACK,
                                recipeName = plan.snackRecipeName,
                                recipeUrl = plan.snackRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(plan, MealSlot.SNACK) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(plan, MealSlot.SNACK) }
                            )

                            // Dinner
                            MealSlotItem(
                                slot = MealSlot.DINNER,
                                recipeName = plan.dinnerRecipeName,
                                recipeUrl = plan.dinnerRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(plan, MealSlot.DINNER) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(plan, MealSlot.DINNER) }
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }

    // Confirmation dialog for regenerating month
    if (showRegenerateDialog) {
        AlertDialog(
            onDismissRequest = { showRegenerateDialog = false },
            title = { Text("Regenerate Meal Plan?") },
            text = {
                Text(
                    "This will regenerate the entire meal plan for ${viewModel.getMonthName(selectedMonth)} $selectedYear. Any manual changes you made for this month will be replaced with a fresh schedule adhering to all rules."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRegenerateDialog = false
                        viewModel.regenerateCurrentMonth()
                    },
                    modifier = Modifier.testTag("confirm_regenerate_button")
                ) {
                    Text("Regenerate")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showRegenerateDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun DayHeaderInfo(
    plan: DailyMealPlan,
    onChangeDayPlan: () -> Unit
) {
    val isSunday = plan.dayOfWeek.equals("SUNDAY", ignoreCase = true)
    val isSaturday = plan.dayOfWeek.equals("SATURDAY", ignoreCase = true)

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${plan.dayOfMonth}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "${plan.dayOfWeek.lowercase().replaceFirstChar { it.uppercase() }}, ${plan.dateIso}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isSunday) "Sunday Biryani Lunch • Sunday Specials"
                        else if (isSaturday) "Saturday Rule: All Meals Vegetarian"
                        else "Mon-Fri: Rice + Curry + Fry Lunch",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (isSunday) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.tertiaryContainer
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = MaterialTheme.colorScheme.onTertiaryContainer, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Sunday",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            } else if (isSaturday) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Eco, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Veg",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Requirement 6: The Change button on a daily meal plan regenerates the ENTIRE selected day's plan
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = onChangeDayPlan,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("change_day_plan_btn_${plan.dayOfMonth}")
            ) {
                Icon(
                    imageVector = Icons.Default.Autorenew,
                    contentDescription = "Change Day Plan",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Change Day Plan",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun LunchCardSection(
    plan: DailyMealPlan,
    onSlotChange: (MealSlot) -> Unit,
    onBrowseAlternatives: (MealSlot) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (plan.lunchType == "BIRYANI") "Lunch: Sunday Biryani Special" else "Lunch: 3 Components (Independent Change)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                if (plan.lunchType != "BIRYANI") {
                    Text(
                        text = "Rice + Curry + Fry",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (plan.lunchType == "BIRYANI") {
                MealSlotItem(
                    slot = MealSlot.LUNCH_BIRYANI,
                    recipeName = plan.lunchBiryaniRecipeName,
                    recipeUrl = plan.lunchBiryaniRecipeUrl,
                    onChangeClicked = { onSlotChange(MealSlot.LUNCH_BIRYANI) },
                    onBrowseAlternatives = { onBrowseAlternatives(MealSlot.LUNCH_BIRYANI) },
                    isSubComponent = true,
                    modifier = Modifier.testTag("lunch_biryani_item_${plan.dayOfMonth}")
                )
            } else {
                // 1. Rice component
                MealSlotItem(
                    slot = MealSlot.LUNCH_RICE,
                    recipeName = plan.lunchRiceRecipeName,
                    recipeUrl = plan.lunchRiceRecipeUrl,
                    onChangeClicked = { onSlotChange(MealSlot.LUNCH_RICE) },
                    onBrowseAlternatives = { onBrowseAlternatives(MealSlot.LUNCH_RICE) },
                    isSubComponent = true,
                    modifier = Modifier.testTag("lunch_rice_item_${plan.dayOfMonth}")
                )

                // 2. Curry component
                MealSlotItem(
                    slot = MealSlot.LUNCH_CURRY,
                    recipeName = plan.lunchCurryRecipeName,
                    recipeUrl = plan.lunchCurryRecipeUrl,
                    onChangeClicked = { onSlotChange(MealSlot.LUNCH_CURRY) },
                    onBrowseAlternatives = { onBrowseAlternatives(MealSlot.LUNCH_CURRY) },
                    isSubComponent = true,
                    modifier = Modifier.testTag("lunch_curry_item_${plan.dayOfMonth}")
                )

                // 3. Fry component
                MealSlotItem(
                    slot = MealSlot.LUNCH_FRY,
                    recipeName = plan.lunchFryRecipeName,
                    recipeUrl = plan.lunchFryRecipeUrl,
                    onChangeClicked = { onSlotChange(MealSlot.LUNCH_FRY) },
                    onBrowseAlternatives = { onBrowseAlternatives(MealSlot.LUNCH_FRY) },
                    isSubComponent = true,
                    modifier = Modifier.testTag("lunch_fry_item_${plan.dayOfMonth}")
                )
            }
        }
    }
}
