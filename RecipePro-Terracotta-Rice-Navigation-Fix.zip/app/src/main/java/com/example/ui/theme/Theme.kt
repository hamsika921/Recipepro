package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ForestGreenLight,
    onPrimary = Color(0xFF2B160F),
    primaryContainer = Color(0xFF573327),
    onPrimaryContainer = Color(0xFFFFE5D8),
    secondary = SageGreenLight,
    onSecondary = Color(0xFF2B160F),
    secondaryContainer = Color(0xFF493128),
    onSecondaryContainer = Color(0xFFF6DCCE),
    tertiary = WarmTerracottaContainer,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    outline = Color(0xFF9D7563),
    outlineVariant = Color(0xFF594137)
)

private val LightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,
    onPrimary = ForestGreenOnPrimary,
    primaryContainer = SageGreenContainer,
    onPrimaryContainer = SageGreenOnContainer,
    secondary = OliveSecondary,
    onSecondary = Color.White,
    secondaryContainer = OliveSecondaryContainer,
    onSecondaryContainer = OliveOnSecondaryContainer,
    tertiary = WarmTerracotta,
    onTertiary = Color.White,
    tertiaryContainer = WarmTerracottaContainer,
    onTertiaryContainer = WarmTerracottaOnContainer,
    background = CreamBackground,
    onBackground = Color(0xFF1E241E),
    surface = CreamSurface,
    onSurface = Color(0xFF1E241E),
    surfaceVariant = CreamSurfaceVariant,
    onSurfaceVariant = Color(0xFF4C554D),
    outline = OutlineWarm,
    outlineVariant = OutlineWarmVariant
)

@Composable
fun RecipeProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep warm culinary aesthetic consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
