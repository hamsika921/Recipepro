package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DailyMealPlan
import com.example.planner.MealSlot
import com.example.ui.components.MealSlotItem
import com.example.ui.viewmodel.RecipeProViewModel
import com.example.ui.viewmodel.ScreenTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: RecipeProViewModel,
    todayPlan: DailyMealPlan?,
    recipeCount: Int,
    onNavigateTab: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Welcome Header
            ElevatedCard(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_header_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RecipePro",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Smart Meal Planner & Recipe Vault",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RestaurantMenu,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickMetricChip(
                            label = "$recipeCount Recipes",
                            icon = Icons.Default.CollectionsBookmark,
                            modifier = Modifier.weight(1f)
                        )
                        QuickMetricChip(
                            label = "27 Collections",
                            icon = Icons.Default.RestaurantMenu,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Today's Meal Plan Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Today's Meal Plan",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    todayPlan?.let {
                        Text(
                            text = "${it.dayOfWeek.lowercase().replaceFirstChar { c -> c.uppercase() }}, ${it.dateIso}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Rule badges
                todayPlan?.let { plan ->
                    if (plan.dayOfWeek.equals("SUNDAY", ignoreCase = true)) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Sunday Biryani",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    } else if (plan.dayOfWeek.equals("SATURDAY", ignoreCase = true)) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Eco,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Saturday Veg",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }

        if (todayPlan == null) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No plan generated for today yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // Breakfast
            item {
                MealSlotItem(
                    slot = MealSlot.BREAKFAST,
                    recipeName = todayPlan.breakfastRecipeName,
                    recipeUrl = todayPlan.breakfastRecipeUrl,
                    onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.BREAKFAST) },
                    onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.BREAKFAST) },
                    modifier = Modifier.testTag("today_breakfast_item")
                )
            }

            // Lunch
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("today_lunch_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Text(
                            text = if (todayPlan.lunchType == "BIRYANI") "Lunch (Sunday Biryani)" else "Lunch (3 Components: Rice + Curry + Fry)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        if (todayPlan.lunchType == "BIRYANI") {
                            MealSlotItem(
                                slot = MealSlot.LUNCH_BIRYANI,
                                recipeName = todayPlan.lunchBiryaniRecipeName,
                                recipeUrl = todayPlan.lunchBiryaniRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.LUNCH_BIRYANI) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.LUNCH_BIRYANI) },
                                isSubComponent = true,
                                modifier = Modifier.testTag("today_lunch_biryani_item")
                            )
                        } else {
                            MealSlotItem(
                                slot = MealSlot.LUNCH_RICE,
                                recipeName = todayPlan.lunchRiceRecipeName,
                                recipeUrl = todayPlan.lunchRiceRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.LUNCH_RICE) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.LUNCH_RICE) },
                                isSubComponent = true,
                                modifier = Modifier.testTag("today_lunch_rice_item")
                            )

                            MealSlotItem(
                                slot = MealSlot.LUNCH_CURRY,
                                recipeName = todayPlan.lunchCurryRecipeName,
                                recipeUrl = todayPlan.lunchCurryRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.LUNCH_CURRY) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.LUNCH_CURRY) },
                                isSubComponent = true,
                                modifier = Modifier.testTag("today_lunch_curry_item")
                            )

                            MealSlotItem(
                                slot = MealSlot.LUNCH_FRY,
                                recipeName = todayPlan.lunchFryRecipeName,
                                recipeUrl = todayPlan.lunchFryRecipeUrl,
                                onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.LUNCH_FRY) },
                                onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.LUNCH_FRY) },
                                isSubComponent = true,
                                modifier = Modifier.testTag("today_lunch_fry_item")
                            )
                        }
                    }
                }
            }

            // Evening Snack
            item {
                MealSlotItem(
                    slot = MealSlot.SNACK,
                    recipeName = todayPlan.snackRecipeName,
                    recipeUrl = todayPlan.snackRecipeUrl,
                    onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.SNACK) },
                    onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.SNACK) },
                    modifier = Modifier.testTag("today_snack_item")
                )
            }

            // Dinner
            item {
                MealSlotItem(
                    slot = MealSlot.DINNER,
                    recipeName = todayPlan.dinnerRecipeName,
                    recipeUrl = todayPlan.dinnerRecipeUrl,
                    onChangeClicked = { viewModel.onSlotChangeClicked(todayPlan, MealSlot.DINNER) },
                    onBrowseAlternatives = { viewModel.openSlotAlternativePicker(todayPlan, MealSlot.DINNER) },
                    modifier = Modifier.testTag("today_dinner_item")
                )
            }
        }

        // Quick Navigation Links
        item {
            Text(
                text = "Quick Actions",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickNavCard(
                    title = "Monthly Planner",
                    subtitle = "View 30-day calendar",
                    icon = Icons.Default.CalendarMonth,
                    onClick = { onNavigateTab(ScreenTab.PLANNER) },
                    modifier = Modifier.weight(1f)
                )

                QuickNavCard(
                    title = "Add Recipe",
                    subtitle = "Paste Pinterest/Insta URL",
                    icon = Icons.Default.Add,
                    onClick = { onNavigateTab(ScreenTab.ADD_RECIPE) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QuickMetricChip(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun QuickNavCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
