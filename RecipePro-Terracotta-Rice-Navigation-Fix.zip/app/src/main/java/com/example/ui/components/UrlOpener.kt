package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object UrlOpener {
    fun openUrl(context: Context, url: String?) {
        if (url.isNullOrBlank()) {
            Toast.makeText(context, "No recipe URL available", Toast.LENGTH_SHORT).show()
            return
        }
        val target = if (!url.startsWith("http://") && !url.startsWith("https://")) {
            "https://$url"
        } else {
            url
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(target)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open URL: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
