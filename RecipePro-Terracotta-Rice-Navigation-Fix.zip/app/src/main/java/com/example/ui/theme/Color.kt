package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RecipePro warm terracotta, cream and espresso palette
val CreamBackground = Color(0xFFF7F0E6)
val CreamSurface = Color(0xFFFFFBF5)
val CreamSurfaceVariant = Color(0xFFE7D5BF)
val OutlineWarm = Color(0xFFD5BDA6)
val OutlineWarmVariant = Color(0xFFE8D9C8)

val ForestGreenPrimary = Color(0xFFC56F4D) // Retained name for compatibility; now terracotta
val ForestGreenOnPrimary = Color(0xFFFFFFFF)
val SageGreenContainer = Color(0xFFF0D2C3)
val SageGreenOnContainer = Color(0xFF512B1C)

val OliveSecondary = Color(0xFF9A5A40)
val OliveSecondaryContainer = Color(0xFFF0DCCF)
val OliveOnSecondaryContainer = Color(0xFF4C2A1E)

val WarmTerracotta = Color(0xFFC56F4D)
val WarmTerracottaContainer = Color(0xFFF0D2C3)
val WarmTerracottaOnContainer = Color(0xFF512B1C)

val DarkBackground = Color(0xFF211815)
val DarkSurface = Color(0xFF2C201B)
val DarkSurfaceVariant = Color(0xFF3B2A23)
val ForestGreenLight = Color(0xFFE49A79)
val SageGreenLight = Color(0xFFE7B49B)
