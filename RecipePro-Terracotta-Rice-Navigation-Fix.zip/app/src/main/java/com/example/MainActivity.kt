package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CollectionsBookmark
import androidx.compose.material.icons.outlined.Fastfood
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AlternativePickerSheet
import com.example.ui.screens.AddRecipeScreen
import com.example.ui.screens.CollectionsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MonthlyPlannerScreen
import com.example.ui.theme.RecipeProTheme
import com.example.ui.viewmodel.RecipeProViewModel
import com.example.ui.viewmodel.ScreenTab
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val themePreferences = getSharedPreferences("recipepro_preferences", MODE_PRIVATE)
        val darkThemeState = androidx.compose.runtime.mutableStateOf(
            themePreferences.getBoolean("dark_theme", false)
        )
        setContent {
            RecipeProTheme(darkTheme = darkThemeState.value) {
                RecipeProApp(
                    darkTheme = darkThemeState.value,
                    onToggleTheme = {
                        val newValue = !darkThemeState.value
                        darkThemeState.value = newValue
                        themePreferences.edit().putBoolean("dark_theme", newValue).apply()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeProApp(
    darkTheme: Boolean,
    onToggleTheme: () -> Unit,
    viewModel: RecipeProViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val todayPlan by viewModel.todayPlan.collectAsState()
    val allRecipes by viewModel.allRecipes.collectAsState()
    val slotPickerState by viewModel.slotPickerState.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var preselectedCollectionForAdd by remember { mutableStateOf<String?>(null) }

    // Listen for feedback messages (Change action results, add recipe success, etc.)
    LaunchedEffect(Unit) {
        viewModel.userMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Handle back button when not on Home tab
    if (currentTab != ScreenTab.HOME) {
        BackHandler {
            viewModel.setTab(ScreenTab.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (currentTab) {
                            ScreenTab.HOME -> "RecipePro"
                            ScreenTab.PLANNER -> "Monthly Meal Planner"
                            ScreenTab.JUNK -> "Daily Junk Selections"
                            ScreenTab.COLLECTIONS -> "Recipe Collections"
                            ScreenTab.ADD_RECIPE -> "Add Recipe"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                actions = {
                    TextButton(onClick = onToggleTheme) {
                        Text(
                            text = if (darkTheme) "☀ Light" else "☾ Dark",
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == ScreenTab.HOME,
                    onClick = { viewModel.setTab(ScreenTab.HOME) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == ScreenTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = { Text("Home") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_tab_home")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.PLANNER,
                    onClick = { viewModel.setTab(ScreenTab.PLANNER) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == ScreenTab.PLANNER) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth,
                            contentDescription = "Planner"
                        )
                    },
                    label = { Text("Planner") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_tab_planner")
                )

                // Requirement 4: Junk navigation tab
                NavigationBarItem(
                    selected = currentTab == ScreenTab.JUNK,
                    onClick = { viewModel.setTab(ScreenTab.JUNK) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == ScreenTab.JUNK) Icons.Filled.Fastfood else Icons.Outlined.Fastfood,
                            contentDescription = "Junk"
                        )
                    },
                    label = { Text("Junk") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.tertiaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.tertiary
                    ),
                    modifier = Modifier.testTag("nav_tab_junk")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.COLLECTIONS,
                    onClick = { viewModel.setTab(ScreenTab.COLLECTIONS) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == ScreenTab.COLLECTIONS) Icons.Filled.CollectionsBookmark else Icons.Outlined.CollectionsBookmark,
                            contentDescription = "Collections"
                        )
                    },
                    label = { Text("Collections") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_tab_collections")
                )

                NavigationBarItem(
                    selected = currentTab == ScreenTab.ADD_RECIPE,
                    onClick = {
                        preselectedCollectionForAdd = null
                        viewModel.setTab(ScreenTab.ADD_RECIPE)
                    },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == ScreenTab.ADD_RECIPE) Icons.Filled.AddCircle else Icons.Outlined.AddCircleOutline,
                            contentDescription = "Add Recipe"
                        )
                    },
                    label = { Text("Add") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_tab_add")
                )
            }
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState, modifier = Modifier.testTag("app_snackbar_host"))
        }
    ) { innerPadding ->
        when (currentTab) {
            ScreenTab.HOME -> {
                HomeScreen(
                    viewModel = viewModel,
                    todayPlan = todayPlan,
                    recipeCount = allRecipes.size,
                    onNavigateTab = { target ->
                        if (target == ScreenTab.ADD_RECIPE) preselectedCollectionForAdd = null
                        viewModel.setTab(target)
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            ScreenTab.PLANNER -> {
                MonthlyPlannerScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
            ScreenTab.JUNK -> {
                com.example.ui.screens.JunkScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
            ScreenTab.COLLECTIONS -> {
                CollectionsScreen(
                    viewModel = viewModel,
                    onNavigateToAddRecipe = { col ->
                        preselectedCollectionForAdd = col
                        viewModel.setTab(ScreenTab.ADD_RECIPE)
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            ScreenTab.ADD_RECIPE -> {
                AddRecipeScreen(
                    viewModel = viewModel,
                    preselectedCollection = preselectedCollectionForAdd,
                    onRecipeAdded = {
                        viewModel.setTab(ScreenTab.COLLECTIONS)
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }

    // Modal Bottom Sheet for alternative recipe selection
    slotPickerState?.let { pickerState ->
        AlternativePickerSheet(
            state = pickerState,
            onSelect = { recipe ->
                viewModel.applySpecificAlternative(recipe)
            },
            onDismiss = {
                viewModel.closeSlotAlternativePicker()
            }
        )
    }
}
