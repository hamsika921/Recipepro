package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.DailyJunkPlan
import com.example.data.model.DailyMealPlan
import com.example.data.model.Recipe
import com.example.data.model.UserCollection
import com.example.planner.MealPlanningConfig

@Database(
    entities = [Recipe::class, DailyMealPlan::class, UserCollection::class, DailyJunkPlan::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun recipeDao(): RecipeDao
    abstract fun mealPlanDao(): MealPlanDao
    abstract fun collectionDao(): CollectionDao
    abstract fun junkDao(): JunkDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `user_collections` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `name` TEXT NOT NULL,
                        `isPredefined` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_user_collections_name` ON `user_collections` (`name`)"
                )
                val now = System.currentTimeMillis()
                for (col in MealPlanningConfig.PREDEFINED_COLLECTIONS) {
                    val escapedName = col.replace("'", "''")
                    db.execSQL(
                        "INSERT OR IGNORE INTO `user_collections` (`name`, `isPredefined`, `createdAt`) VALUES ('$escapedName', 1, $now)"
                    )
                }
                db.execSQL(
                    """
                    INSERT OR IGNORE INTO `user_collections` (`name`, `isPredefined`, `createdAt`)
                    SELECT DISTINCT `collectionName`, 0, $now FROM `recipes`
                    WHERE `collectionName` IS NOT NULL AND `collectionName` != ''
                    """.trimIndent()
                )
            }
        }

        /**
         * Safe migration from Version 2 to Version 3:
         * 1. Updates any "Sandwiches / Burgers" to "Sandwich / Burgers".
         * 2. Inserts all 27 exact predefined collections into user_collections.
         * 3. Creates the daily_junk_plans table for Junk selections.
         * Preserves 100% of existing recipes, collections, URLs, and meal plans.
         */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val now = System.currentTimeMillis()

                // Normalize Sandwich / Burgers name if previously Sandwiches / Burgers
                db.execSQL("UPDATE `user_collections` SET `name` = 'Sandwich / Burgers' WHERE `name` = 'Sandwiches / Burgers'")
                db.execSQL("UPDATE `recipes` SET `collectionName` = 'Sandwich / Burgers' WHERE `collectionName` = 'Sandwiches / Burgers'")

                // Ensure all exact 27 predefined collections exist
                for (col in MealPlanningConfig.PREDEFINED_COLLECTIONS) {
                    val escaped = col.replace("'", "''")
                    db.execSQL(
                        "INSERT OR IGNORE INTO `user_collections` (`name`, `isPredefined`, `createdAt`) VALUES ('$escaped', 1, $now)"
                    )
                }

                // Create daily_junk_plans table
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `daily_junk_plans` (
                        `dateIso` TEXT NOT NULL PRIMARY KEY,
                        `breadRecipeId` INTEGER,
                        `breadRecipeName` TEXT,
                        `breadRecipeUrl` TEXT,
                        `mixturesRecipeId` INTEGER,
                        `mixturesRecipeName` TEXT,
                        `mixturesRecipeUrl` TEXT,
                        `cakesRecipeId` INTEGER,
                        `cakesRecipeName` TEXT,
                        `cakesRecipeUrl` TEXT,
                        `cookiesRecipeId` INTEGER,
                        `cookiesRecipeName` TEXT,
                        `cookiesRecipeUrl` TEXT,
                        `chocolateRecipeId` INTEGER,
                        `chocolateRecipeName` TEXT,
                        `chocolateRecipeUrl` TEXT,
                        `juiceRecipeId` INTEGER,
                        `juiceRecipeName` TEXT,
                        `juiceRecipeUrl` TEXT,
                        `iceCreamRecipeId` INTEGER,
                        `iceCreamRecipeName` TEXT,
                        `iceCreamRecipeUrl` TEXT,
                        `sweetsRecipeId` INTEGER,
                        `sweetsRecipeName` TEXT,
                        `sweetsRecipeUrl` TEXT,
                        `updatedAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "recipe_pro_database"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
