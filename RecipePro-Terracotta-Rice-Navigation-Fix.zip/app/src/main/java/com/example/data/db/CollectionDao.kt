package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.UserCollection
import kotlinx.coroutines.flow.Flow

@Dao
interface CollectionDao {

    @Query("SELECT * FROM user_collections ORDER BY isPredefined DESC, name ASC")
    fun getAllCollections(): Flow<List<UserCollection>>

    @Query("SELECT * FROM user_collections ORDER BY isPredefined DESC, name ASC")
    suspend fun getAllCollectionsSnapshot(): List<UserCollection>

    @Query("SELECT * FROM user_collections WHERE LOWER(TRIM(name)) = LOWER(TRIM(:name)) LIMIT 1")
    suspend fun getCollectionByName(name: String): UserCollection?

    @Query("SELECT COUNT(*) FROM user_collections WHERE LOWER(TRIM(name)) = LOWER(TRIM(:name)) AND (:excludeId IS NULL OR id != :excludeId)")
    suspend fun countDuplicateName(name: String, excludeId: Long?): Int

    @Query("SELECT COUNT(*) FROM user_collections")
    suspend fun countCollections(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCollection(collection: UserCollection): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCollections(collections: List<UserCollection>)

    @Update
    suspend fun updateCollection(collection: UserCollection)

    @Query("UPDATE user_collections SET name = :newName WHERE name = :oldName")
    suspend fun renameCollection(oldName: String, newName: String)

    @Query("DELETE FROM user_collections WHERE name = :name AND isPredefined = 0")
    suspend fun deleteCustomCollection(name: String)
}
