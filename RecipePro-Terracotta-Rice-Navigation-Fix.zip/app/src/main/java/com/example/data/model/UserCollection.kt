package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "user_collections",
    indices = [
        Index(value = ["name"], unique = true)
    ]
)
data class UserCollection(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val isPredefined: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
