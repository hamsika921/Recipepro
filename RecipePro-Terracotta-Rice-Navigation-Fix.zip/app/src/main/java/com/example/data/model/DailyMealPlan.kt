package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Represents a single day's meal plan in the monthly planner.
 * Supports breakfast, evening snack, dinner, and lunch.
 * Lunch has 3 independent components on Monday-Saturday (Rice + Curry + Fry),
 * or Biryani on Sunday.
 */
@Entity(
    tableName = "daily_meal_plans",
    indices = [
        Index(value = ["dateIso"], unique = true),
        Index(value = ["yearMonth"])
    ]
)
data class DailyMealPlan(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val yearMonth: String,       // e.g. "2026-10"
    val dateIso: String,         // e.g. "2026-10-11"
    val dayOfMonth: Int,         // 1..31
    val dayOfWeek: String,       // "MONDAY", "TUESDAY", ... "SUNDAY"

    // Breakfast
    val breakfastRecipeId: Long? = null,
    val breakfastRecipeName: String? = null,
    val breakfastRecipeUrl: String? = null,

    // Lunch: COMPONENTS (Mon-Sat) or BIRYANI (Sun)
    val lunchType: String = if (dayOfWeek.equals("SUNDAY", ignoreCase = true)) "BIRYANI" else "COMPONENTS",

    val lunchRiceRecipeId: Long? = null,
    val lunchRiceRecipeName: String? = null,
    val lunchRiceRecipeUrl: String? = null,

    val lunchCurryRecipeId: Long? = null,
    val lunchCurryRecipeName: String? = null,
    val lunchCurryRecipeUrl: String? = null,

    val lunchFryRecipeId: Long? = null,
    val lunchFryRecipeName: String? = null,
    val lunchFryRecipeUrl: String? = null,

    val lunchBiryaniRecipeId: Long? = null,
    val lunchBiryaniRecipeName: String? = null,
    val lunchBiryaniRecipeUrl: String? = null,

    // Evening Snack
    val snackRecipeId: Long? = null,
    val snackRecipeName: String? = null,
    val snackRecipeUrl: String? = null,

    // Dinner
    val dinnerRecipeId: Long? = null,
    val dinnerRecipeName: String? = null,
    val dinnerRecipeUrl: String? = null
)
