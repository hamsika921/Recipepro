package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Recipe entity.
 * Per specification:
 * Each recipe contains ONLY:
 * - Recipe Name
 * - Recipe URL (Pinterest or Instagram link)
 * associated with a predefined collection.
 */
@Entity(
    tableName = "recipes",
    indices = [
        Index(value = ["collectionName", "name"], unique = true)
    ]
)
data class Recipe(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val url: String,
    val collectionName: String,
    val createdAt: Long = System.currentTimeMillis()
)
