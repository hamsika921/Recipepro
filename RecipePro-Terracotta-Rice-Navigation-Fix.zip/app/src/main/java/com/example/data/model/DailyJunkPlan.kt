package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stores daily selections for the 8 Junk categories:
 * Bread, Mixtures, Cakes, Cookies / Biscuits, Chocolate, Juice, Ice Cream, Sweets.
 */
@Entity(tableName = "daily_junk_plans")
data class DailyJunkPlan(
    @PrimaryKey
    val dateIso: String, // e.g. "2026-10-11"

    val breadRecipeId: Long? = null,
    val breadRecipeName: String? = null,
    val breadRecipeUrl: String? = null,

    val mixturesRecipeId: Long? = null,
    val mixturesRecipeName: String? = null,
    val mixturesRecipeUrl: String? = null,

    val cakesRecipeId: Long? = null,
    val cakesRecipeName: String? = null,
    val cakesRecipeUrl: String? = null,

    val cookiesRecipeId: Long? = null,
    val cookiesRecipeName: String? = null,
    val cookiesRecipeUrl: String? = null,

    val chocolateRecipeId: Long? = null,
    val chocolateRecipeName: String? = null,
    val chocolateRecipeUrl: String? = null,

    val juiceRecipeId: Long? = null,
    val juiceRecipeName: String? = null,
    val juiceRecipeUrl: String? = null,

    val iceCreamRecipeId: Long? = null,
    val iceCreamRecipeName: String? = null,
    val iceCreamRecipeUrl: String? = null,

    val sweetsRecipeId: Long? = null,
    val sweetsRecipeName: String? = null,
    val sweetsRecipeUrl: String? = null,

    val updatedAt: Long = System.currentTimeMillis()
)
