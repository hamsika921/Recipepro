package com.example.data.repository

import com.example.data.db.CollectionDao
import com.example.data.db.JunkDao
import com.example.data.db.MealPlanDao
import com.example.data.db.RecipeDao
import com.example.data.model.DailyJunkPlan
import com.example.data.model.DailyMealPlan
import com.example.data.model.Recipe
import com.example.data.model.UserCollection
import com.example.planner.ChangeResult
import com.example.planner.JunkPlanningEngine
import com.example.planner.MealPlanningConfig
import com.example.planner.MealPlanningEngine
import com.example.planner.MealSlot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class ImportSummary(
    val recipesImported: Int,
    val recipesSkippedDuplicates: Int,
    val collectionsImported: Int,
    val mealPlansImported: Int
)

class RecipeRepository(
    private val recipeDao: RecipeDao,
    private val mealPlanDao: MealPlanDao,
    private val collectionDao: CollectionDao,
    private val junkDao: JunkDao
) {

    val allRecipes: Flow<List<Recipe>> = recipeDao.getAllRecipes()

    val allCollections: Flow<List<UserCollection>> = collectionDao.getAllCollections()

    fun getRecipesByCollection(collection: String): Flow<List<Recipe>> =
        recipeDao.getRecipesByCollection(collection)

    fun searchRecipes(query: String): Flow<List<Recipe>> =
        recipeDao.searchRecipes(query.trim())

    fun getMonthPlans(yearMonth: String): Flow<List<DailyMealPlan>> =
        mealPlanDao.getMonthPlans(yearMonth)

    fun getDayPlan(dateIso: String): Flow<DailyMealPlan?> =
        mealPlanDao.getDayPlan(dateIso)

    fun getDailyJunkPlan(dateIso: String): Flow<DailyJunkPlan?> =
        junkDao.getJunkPlan(dateIso)

    /**
     * Requirement 8: Do not generate fake recipes or sample data.
     * Ensures all exact 27 predefined collections exist in the database without creating sample recipes.
     */
    suspend fun initCollectionsIfEmpty() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        for (name in MealPlanningConfig.PREDEFINED_COLLECTIONS) {
            val exists = collectionDao.countDuplicateName(name, null)
            if (exists == 0) {
                collectionDao.insertCollection(
                    UserCollection(name = name, isPredefined = true, createdAt = now)
                )
            }
        }
    }

    /**
     * Requirement 5: Prevent duplicate recipe names across the ENTIRE recipe library,
     * ignoring capitalization and leading or trailing spaces.
     */
    suspend fun addRecipe(name: String, url: String, collectionName: String): Result<Long> = withContext(Dispatchers.IO) {
        val cleanName = name.trim()
        val cleanUrl = url.trim()
        val cleanCol = collectionName.trim()

        if (cleanName.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe name is required."))
        }
        if (cleanUrl.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe URL is required."))
        }
        if (cleanCol.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please select a collection."))
        }

        val normalizedUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            "https://$cleanUrl"
        } else {
            cleanUrl
        }

        val duplicateCount = recipeDao.countDuplicateNameAcrossAll(cleanName, null)
        if (duplicateCount > 0) {
            return@withContext Result.failure(
                IllegalArgumentException("A recipe named '$cleanName' already exists. Recipe names must be unique across all collections.")
            )
        }

        try {
            val id = recipeDao.insertRecipe(
                Recipe(
                    name = cleanName,
                    url = normalizedUrl,
                    collectionName = cleanCol
                )
            )
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateRecipe(recipe: Recipe): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanName = recipe.name.trim()
        val cleanUrl = recipe.url.trim()
        val cleanCol = recipe.collectionName.trim()

        if (cleanName.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe name cannot be blank."))
        }
        if (cleanUrl.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe URL cannot be blank."))
        }

        val normalizedUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            "https://$cleanUrl"
        } else {
            cleanUrl
        }

        val duplicateCount = recipeDao.countDuplicateNameAcrossAll(cleanName, recipe.id)
        if (duplicateCount > 0) {
            return@withContext Result.failure(
                IllegalArgumentException("Another recipe named '$cleanName' already exists in your collections.")
            )
        }

        try {
            recipeDao.updateRecipe(recipe.copy(name = cleanName, url = normalizedUrl, collectionName = cleanCol))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteRecipe(recipeId: Long) = withContext(Dispatchers.IO) {
        recipeDao.deleteRecipeById(recipeId)
    }

    // --- Requirement 3: Custom Collections (Add, Rename, Delete) ---

    suspend fun createCollection(name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val clean = name.trim()
        if (clean.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Collection name cannot be blank."))
        }

        // Never duplicate a predefined collection
        if (MealPlanningConfig.PREDEFINED_COLLECTIONS.any { it.trim().equals(clean, ignoreCase = true) }) {
            return@withContext Result.failure(IllegalArgumentException("'$clean' is already a predefined collection."))
        }

        // Never duplicate another custom collection
        val exists = collectionDao.countDuplicateName(clean, null)
        if (exists > 0) {
            return@withContext Result.failure(IllegalArgumentException("A collection named '$clean' already exists."))
        }

        try {
            collectionDao.insertCollection(UserCollection(name = clean, isPredefined = false))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun renameCollection(oldName: String, newName: String): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanOld = oldName.trim()
        val cleanNew = newName.trim()

        if (cleanNew.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("New collection name cannot be blank."))
        }
        if (cleanOld.equals(cleanNew, ignoreCase = true)) {
            return@withContext Result.success(Unit)
        }

        if (MealPlanningConfig.PREDEFINED_COLLECTIONS.any { it.trim().equals(cleanNew, ignoreCase = true) }) {
            return@withContext Result.failure(IllegalArgumentException("'$cleanNew' is already a predefined collection."))
        }

        val exists = collectionDao.countDuplicateName(cleanNew, null)
        if (exists > 0) {
            return@withContext Result.failure(IllegalArgumentException("A collection named '$cleanNew' already exists."))
        }

        try {
            collectionDao.renameCollection(cleanOld, cleanNew)
            recipeDao.updateCollectionNameForRecipes(cleanOld, cleanNew)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteCollection(name: String): Result<Unit> = withContext(Dispatchers.IO) {
        val clean = name.trim()
        val col = collectionDao.getCollectionByName(clean)
            ?: return@withContext Result.failure(IllegalArgumentException("Collection not found."))

        if (col.isPredefined) {
            return@withContext Result.failure(IllegalArgumentException("Predefined collections cannot be deleted."))
        }

        val recipesInCol = recipeDao.countRecipesInCollection(clean)
        if (recipesInCol > 0) {
            return@withContext Result.failure(
                IllegalArgumentException("Cannot delete '$clean' because it contains $recipesInCol recipe(s). Please move or delete them first.")
            )
        }

        try {
            collectionDao.deleteCustomCollection(clean)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Requirement 6: Meal Planner & The Complete Day Change Button ---

    suspend fun ensureMonthPlanGenerated(year: Int, month: Int) = withContext(Dispatchers.IO) {
        val yearMonthStr = String.format(Locale.US, "%04d-%02d", year, month)
        val existingCount = mealPlanDao.countMonthPlans(yearMonthStr)
        if (existingCount == 0) {
            val all = recipeDao.getAllRecipesSnapshot()
            val plans = MealPlanningEngine.generateMonthPlan(year, month, all)
            mealPlanDao.insertPlans(plans)
        }
    }

    suspend fun regenerateMonthPlan(year: Int, month: Int) = withContext(Dispatchers.IO) {
        val yearMonthStr = String.format(Locale.US, "%04d-%02d", year, month)
        mealPlanDao.deleteMonthPlans(yearMonthStr)
        val all = recipeDao.getAllRecipesSnapshot()
        val plans = MealPlanningEngine.generateMonthPlan(year, month, all)
        mealPlanDao.insertPlans(plans)
    }

    /**
     * Requirement 6: The Change button on a daily meal plan regenerates the ENTIRE
     * selected day's plan (breakfast, lunch components, evening snack, dinner)
     * without modifying any other day, and saves immediately.
     */
    suspend fun regenerateEntireDayPlan(plan: DailyMealPlan): DailyMealPlan = withContext(Dispatchers.IO) {
        val allRecipes = recipeDao.getAllRecipesSnapshot()
        val monthPlans = mealPlanDao.getMonthPlansSnapshot(plan.yearMonth)

        val updatedPlan = MealPlanningEngine.regenerateEntireDayPlan(plan, allRecipes, monthPlans)
        mealPlanDao.insertOrUpdatePlan(updatedPlan)
        updatedPlan
    }

    suspend fun changeMeal(
        plan: DailyMealPlan,
        slot: MealSlot,
        forcedReplacement: Recipe? = null
    ): ChangeResult = withContext(Dispatchers.IO) {
        val allRecipes = recipeDao.getAllRecipesSnapshot()
        val monthPlans = mealPlanDao.getMonthPlansSnapshot(plan.yearMonth)

        val result = MealPlanningEngine.changeMeal(
            currentPlan = plan,
            slot = slot,
            allRecipes = allRecipes,
            monthPlans = monthPlans,
            forcedReplacementRecipe = forcedReplacement
        )

        if (result is ChangeResult.Success) {
            mealPlanDao.insertOrUpdatePlan(result.updatedPlan)
        }

        result
    }

    suspend fun getEligibleAlternatives(
        plan: DailyMealPlan,
        slot: MealSlot
    ): List<Recipe> = withContext(Dispatchers.IO) {
        val allRecipes = recipeDao.getAllRecipesSnapshot()
        val monthPlans = mealPlanDao.getMonthPlansSnapshot(plan.yearMonth)
        val isSunday = plan.dayOfWeek.equals("SUNDAY", ignoreCase = true)
        val isSaturday = plan.dayOfWeek.equals("SATURDAY", ignoreCase = true)

        val currentRecipeId = when (slot) {
            MealSlot.BREAKFAST -> plan.breakfastRecipeId
            MealSlot.LUNCH_RICE -> plan.lunchRiceRecipeId
            MealSlot.LUNCH_CURRY -> plan.lunchCurryRecipeId
            MealSlot.LUNCH_FRY -> plan.lunchFryRecipeId
            MealSlot.LUNCH_BIRYANI -> plan.lunchBiryaniRecipeId
            MealSlot.SNACK -> plan.snackRecipeId
            MealSlot.DINNER -> plan.dinnerRecipeId
        }

        MealPlanningEngine.getEligibleAlternatives(
            slot = slot,
            recipes = allRecipes,
            isSunday = isSunday,
            isSaturday = isSaturday,
            currentRecipeId = currentRecipeId,
            monthPlans = monthPlans
        )
    }

    // --- Requirement 4: Junk Daily Selections ---

    suspend fun ensureDailyJunkPlan(dateIso: String) = withContext(Dispatchers.IO) {
        val existing = junkDao.getJunkPlanSnapshot(dateIso)
        if (existing == null) {
            val allRecipes = recipeDao.getAllRecipesSnapshot()
            val newPlan = JunkPlanningEngine.generateDailyJunkPlan(dateIso, allRecipes, null)
            junkDao.insertOrUpdate(newPlan)
        }
    }

    suspend fun generateNewDailyJunkPlan(dateIso: String): DailyJunkPlan = withContext(Dispatchers.IO) {
        val allRecipes = recipeDao.getAllRecipesSnapshot()
        val existing = junkDao.getJunkPlanSnapshot(dateIso)
        val newPlan = JunkPlanningEngine.generateDailyJunkPlan(dateIso, allRecipes, existing)
        junkDao.insertOrUpdate(newPlan)
        newPlan
    }

    // --- Backup and Restoration (Export & Import) ---

    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("app", "RecipePro")
        root.put("version", 3)
        root.put("timestamp", System.currentTimeMillis())

        val collections = collectionDao.getAllCollectionsSnapshot()
        val collectionsArray = JSONArray()
        for (col in collections) {
            val obj = JSONObject()
            obj.put("name", col.name)
            obj.put("isPredefined", col.isPredefined)
            collectionsArray.put(obj)
        }
        root.put("collections", collectionsArray)

        val recipes = recipeDao.getAllRecipesSnapshot()
        val recipesArray = JSONArray()
        for (r in recipes) {
            val obj = JSONObject()
            obj.put("name", r.name)
            obj.put("url", r.url)
            obj.put("collectionName", r.collectionName)
            obj.put("createdAt", r.createdAt)
            recipesArray.put(obj)
        }
        root.put("recipes", recipesArray)

        val mealPlansArray = JSONArray()
        val allPlans = mealPlanDao.getMonthPlansSnapshot("2026-10")
        for (p in allPlans) {
            val obj = JSONObject()
            obj.put("yearMonth", p.yearMonth)
            obj.put("dateIso", p.dateIso)
            obj.put("dayOfMonth", p.dayOfMonth)
            obj.put("dayOfWeek", p.dayOfWeek)
            obj.put("breakfastRecipeName", p.breakfastRecipeName)
            obj.put("breakfastRecipeUrl", p.breakfastRecipeUrl)
            obj.put("lunchType", p.lunchType)
            obj.put("lunchRiceRecipeName", p.lunchRiceRecipeName)
            obj.put("lunchRiceRecipeUrl", p.lunchRiceRecipeUrl)
            obj.put("lunchCurryRecipeName", p.lunchCurryRecipeName)
            obj.put("lunchCurryRecipeUrl", p.lunchCurryRecipeUrl)
            obj.put("lunchFryRecipeName", p.lunchFryRecipeName)
            obj.put("lunchFryRecipeUrl", p.lunchFryRecipeUrl)
            obj.put("lunchBiryaniRecipeName", p.lunchBiryaniRecipeName)
            obj.put("lunchBiryaniRecipeUrl", p.lunchBiryaniRecipeUrl)
            obj.put("snackRecipeName", p.snackRecipeName)
            obj.put("snackRecipeUrl", p.snackRecipeUrl)
            obj.put("dinnerRecipeName", p.dinnerRecipeName)
            obj.put("dinnerRecipeUrl", p.dinnerRecipeUrl)
            mealPlansArray.put(obj)
        }
        root.put("mealPlans", mealPlansArray)

        root.toString(2)
    }

    suspend fun importBackupJson(jsonString: String): Result<ImportSummary> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)

            var collectionsImported = 0
            var recipesImported = 0
            var duplicatesSkipped = 0
            var plansImported = 0

            // 1. Collections
            if (root.has("collections")) {
                val collectionsArray = root.getJSONArray("collections")
                for (i in 0 until collectionsArray.length()) {
                    val obj = collectionsArray.getJSONObject(i)
                    val name = obj.getString("name").trim()
                    val isPredefined = obj.optBoolean("isPredefined", false)
                    val exists = collectionDao.countDuplicateName(name, null)
                    if (exists == 0) {
                        collectionDao.insertCollection(UserCollection(name = name, isPredefined = isPredefined))
                        collectionsImported++
                    }
                }
            }

            // 2. Recipes
            if (root.has("recipes")) {
                val recipesArray = root.getJSONArray("recipes")
                for (i in 0 until recipesArray.length()) {
                    val obj = recipesArray.getJSONObject(i)
                    val name = obj.getString("name").trim()
                    val url = obj.getString("url").trim()
                    val collectionName = obj.getString("collectionName").trim()

                    if (collectionDao.countDuplicateName(collectionName, null) == 0) {
                        collectionDao.insertCollection(UserCollection(name = collectionName, isPredefined = false))
                        collectionsImported++
                    }

                    val duplicateCount = recipeDao.countDuplicateNameAcrossAll(name, null)
                    if (duplicateCount > 0) {
                        duplicatesSkipped++
                    } else {
                        recipeDao.insertRecipe(
                            Recipe(
                                name = name,
                                url = url,
                                collectionName = collectionName,
                                createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                            )
                        )
                        recipesImported++
                    }
                }
            }

            // 3. Meal plans
            if (root.has("mealPlans")) {
                val plansArray = root.getJSONArray("mealPlans")
                for (i in 0 until plansArray.length()) {
                    val obj = plansArray.getJSONObject(i)
                    val dateIso = obj.getString("dateIso")
                    val existing = mealPlanDao.getDayPlanSnapshot(dateIso)
                    val plan = DailyMealPlan(
                        id = existing?.id ?: 0,
                        yearMonth = obj.getString("yearMonth"),
                        dateIso = dateIso,
                        dayOfMonth = obj.getInt("dayOfMonth"),
                        dayOfWeek = obj.getString("dayOfWeek"),
                        breakfastRecipeName = obj.optString("breakfastRecipeName", null),
                        breakfastRecipeUrl = obj.optString("breakfastRecipeUrl", null),
                        lunchType = obj.optString("lunchType", "COMPONENTS"),
                        lunchRiceRecipeName = obj.optString("lunchRiceRecipeName", null),
                        lunchRiceRecipeUrl = obj.optString("lunchRiceRecipeUrl", null),
                        lunchCurryRecipeName = obj.optString("lunchCurryRecipeName", null),
                        lunchCurryRecipeUrl = obj.optString("lunchCurryRecipeUrl", null),
                        lunchFryRecipeName = obj.optString("lunchFryRecipeName", null),
                        lunchFryRecipeUrl = obj.optString("lunchFryRecipeUrl", null),
                        lunchBiryaniRecipeName = obj.optString("lunchBiryaniRecipeName", null),
                        lunchBiryaniRecipeUrl = obj.optString("lunchBiryaniRecipeUrl", null),
                        snackRecipeName = obj.optString("snackRecipeName", null),
                        snackRecipeUrl = obj.optString("snackRecipeUrl", null),
                        dinnerRecipeName = obj.optString("dinnerRecipeName", null),
                        dinnerRecipeUrl = obj.optString("dinnerRecipeUrl", null)
                    )
                    mealPlanDao.insertOrUpdatePlan(plan)
                    plansImported++
                }
            }

            Result.success(
                ImportSummary(
                    recipesImported = recipesImported,
                    recipesSkippedDuplicates = duplicatesSkipped,
                    collectionsImported = collectionsImported,
                    mealPlansImported = plansImported
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
