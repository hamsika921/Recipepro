package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DailyMealPlan
import kotlinx.coroutines.flow.Flow

@Dao
interface MealPlanDao {

    @Query("SELECT * FROM daily_meal_plans WHERE yearMonth = :yearMonth ORDER BY dayOfMonth ASC")
    fun getMonthPlans(yearMonth: String): Flow<List<DailyMealPlan>>

    @Query("SELECT * FROM daily_meal_plans WHERE yearMonth = :yearMonth ORDER BY dayOfMonth ASC")
    suspend fun getMonthPlansSnapshot(yearMonth: String): List<DailyMealPlan>

    @Query("SELECT * FROM daily_meal_plans WHERE dateIso = :dateIso LIMIT 1")
    fun getDayPlan(dateIso: String): Flow<DailyMealPlan?>

    @Query("SELECT * FROM daily_meal_plans WHERE dateIso = :dateIso LIMIT 1")
    suspend fun getDayPlanSnapshot(dateIso: String): DailyMealPlan?

    @Query("SELECT COUNT(*) FROM daily_meal_plans WHERE yearMonth = :yearMonth")
    suspend fun countMonthPlans(yearMonth: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlans(plans: List<DailyMealPlan>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdatePlan(plan: DailyMealPlan): Long

    @Update
    suspend fun updatePlan(plan: DailyMealPlan)

    @Query("DELETE FROM daily_meal_plans WHERE yearMonth = :yearMonth")
    suspend fun deleteMonthPlans(yearMonth: String)
}
