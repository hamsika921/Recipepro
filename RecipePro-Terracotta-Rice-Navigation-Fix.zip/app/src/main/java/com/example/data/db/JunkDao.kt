package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.DailyJunkPlan
import kotlinx.coroutines.flow.Flow

@Dao
interface JunkDao {

    @Query("SELECT * FROM daily_junk_plans WHERE dateIso = :dateIso LIMIT 1")
    fun getJunkPlan(dateIso: String): Flow<DailyJunkPlan?>

    @Query("SELECT * FROM daily_junk_plans WHERE dateIso = :dateIso LIMIT 1")
    suspend fun getJunkPlanSnapshot(dateIso: String): DailyJunkPlan?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(plan: DailyJunkPlan)

    @Query("DELETE FROM daily_junk_plans WHERE dateIso = :dateIso")
    suspend fun deletePlan(dateIso: String)
}
