package com.example

import com.example.data.model.DailyMealPlan
import com.example.data.model.Recipe
import com.example.planner.ChangeResult
import com.example.planner.MealPlanningConfig
import com.example.planner.MealPlanningEngine
import com.example.planner.MealSlot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class RecipeProUnitTest {

    private lateinit var testRecipes: List<Recipe>

    @Before
    fun setup() {
        var idCounter = 1L
        testRecipes = listOf(
            // Breakfast
            Recipe(id = idCounter++, name = "Masala Dosa", url = "https://pinterest.com/1", collectionName = "Chilla / Dosa / Paratha"),
            Recipe(id = idCounter++, name = "Moong Chilla", url = "https://pinterest.com/2", collectionName = "Chilla / Dosa / Paratha"),
            Recipe(id = idCounter++, name = "Pancakes", url = "https://instagram.com/3", collectionName = "Pancakes"),

            // Rice
            Recipe(id = idCounter++, name = "Jeera Rice", url = "https://pinterest.com/4", collectionName = "Rice"),
            Recipe(id = idCounter++, name = "Ghee Rice", url = "https://instagram.com/5", collectionName = "Rice"),

            // Biryani
            Recipe(id = idCounter++, name = "Veg Biryani", url = "https://pinterest.com/6", collectionName = "Biryani"),
            Recipe(id = idCounter++, name = "Paneer Biryani", url = "https://instagram.com/7", collectionName = "Biryani"),

            // Curry
            Recipe(id = idCounter++, name = "Paneer Butter Masala", url = "https://pinterest.com/8", collectionName = "Curry"),
            Recipe(id = idCounter++, name = "Dal Tadka", url = "https://instagram.com/9", collectionName = "Curry"),
            Recipe(id = idCounter++, name = "Chole Masala", url = "https://pinterest.com/10", collectionName = "Curry"),

            // Fry
            Recipe(id = idCounter++, name = "Aloo Fry", url = "https://pinterest.com/11", collectionName = "Fry"),
            Recipe(id = idCounter++, name = "Bhindi Fry", url = "https://instagram.com/12", collectionName = "Fry"),

            // Snacks
            Recipe(id = idCounter++, name = "Punugulu", url = "https://pinterest.com/13", collectionName = "Momo / Punugulu / Bajji"),
            Recipe(id = idCounter++, name = "Potato Chips", url = "https://instagram.com/14", collectionName = "Chips / Potato Rolls"),

            // Dinner
            Recipe(id = idCounter++, name = "Penne Arrabbiata", url = "https://pinterest.com/15", collectionName = "Pasta"),
            Recipe(id = idCounter++, name = "Veg Grilled Sandwich", url = "https://instagram.com/16", collectionName = "Sandwiches / Burgers"),

            // Sunday-only items
            Recipe(id = idCounter++, name = "Garlic Bread", url = "https://pinterest.com/17", collectionName = "Bread"),
            Recipe(id = idCounter++, name = "Chocolate Cake", url = "https://instagram.com/18", collectionName = "Cakes"),
            Recipe(id = idCounter++, name = "Corn Mixture", url = "https://pinterest.com/19", collectionName = "Mixtures"),
            Recipe(id = idCounter++, name = "Choco Chip Cookies", url = "https://instagram.com/20", collectionName = "Cookies / Biscuits"),
            Recipe(id = idCounter++, name = "Dark Chocolate", url = "https://pinterest.com/21", collectionName = "Chocolate")
        )
    }

    @Test
    fun `test month plan generation satisfies Sunday Biryani rule`() {
        val plans = MealPlanningEngine.generateMonthPlan(2026, 10, testRecipes)
        assertEquals(31, plans.size)

        val sundays = plans.filter { it.dayOfWeek == "SUNDAY" }
        assertTrue(sundays.isNotEmpty())

        for (sunday in sundays) {
            assertEquals("BIRYANI", sunday.lunchType)
            assertNotNull(sunday.lunchBiryaniRecipeName)
            assertTrue(
                "Sunday lunch must be Biryani",
                sunday.lunchBiryaniRecipeName == "Veg Biryani" || sunday.lunchBiryaniRecipeName == "Paneer Biryani"
            )
        }
    }

    @Test
    fun `test Mon-Sat lunch contains Rice, Curry, and Fry components`() {
        val plans = MealPlanningEngine.generateMonthPlan(2026, 10, testRecipes)
        val nonSundays = plans.filter { it.dayOfWeek != "SUNDAY" }

        for (day in nonSundays) {
            assertEquals("COMPONENTS", day.lunchType)
            assertNotNull("Rice must be scheduled on non-Sunday", day.lunchRiceRecipeName)
            assertNotNull("Curry must be scheduled on non-Sunday", day.lunchCurryRecipeName)
            assertNotNull("Fry must be scheduled on non-Sunday", day.lunchFryRecipeName)
        }
    }

    @Test
    fun `test Sunday-only items never appear on Monday through Saturday`() {
        val plans = MealPlanningEngine.generateMonthPlan(2026, 10, testRecipes)
        val nonSundays = plans.filter { it.dayOfWeek != "SUNDAY" }

        val sundayOnlyNames = setOf(
            "Garlic Bread", "Chocolate Cake", "Corn Mixture", "Choco Chip Cookies", "Dark Chocolate"
        )

        for (day in nonSundays) {
            assertFalse(sundayOnlyNames.contains(day.breakfastRecipeName))
            assertFalse(sundayOnlyNames.contains(day.lunchRiceRecipeName))
            assertFalse(sundayOnlyNames.contains(day.lunchCurryRecipeName))
            assertFalse(sundayOnlyNames.contains(day.lunchFryRecipeName))
            assertFalse(sundayOnlyNames.contains(day.snackRecipeName))
            assertFalse(sundayOnlyNames.contains(day.dinnerRecipeName))
        }
    }

    @Test
    fun `test Saturday meals are all vegetarian`() {
        // Add a non-veg recipe to the pool
        val recipesWithNonVeg = testRecipes + listOf(
            Recipe(id = 999L, name = "Chicken Keema Paratha", url = "https://pin/keema", collectionName = "Chilla / Dosa / Paratha"),
            Recipe(id = 998L, name = "Fish Fry", url = "https://pin/fish", collectionName = "Fry")
        )

        val plans = MealPlanningEngine.generateMonthPlan(2026, 10, recipesWithNonVeg)
        val saturdays = plans.filter { it.dayOfWeek == "SATURDAY" }
        assertTrue(saturdays.isNotEmpty())

        for (sat in saturdays) {
            assertNotEquals("Chicken Keema Paratha", sat.breakfastRecipeName)
            assertNotEquals("Fish Fry", sat.lunchFryRecipeName)
        }
    }

    @Test
    fun `test Change button replaces only target Curry component in lunch`() {
        val plans = MealPlanningEngine.generateMonthPlan(2026, 10, testRecipes)
        val mondayPlan = plans.first { it.dayOfWeek == "MONDAY" }

        val originalRiceId = mondayPlan.lunchRiceRecipeId
        val originalCurryId = mondayPlan.lunchCurryRecipeId
        val originalFryId = mondayPlan.lunchFryRecipeId
        val originalBreakfastId = mondayPlan.breakfastRecipeId
        val originalDinnerId = mondayPlan.dinnerRecipeId

        val changeResult = MealPlanningEngine.changeMeal(
            currentPlan = mondayPlan,
            slot = MealSlot.LUNCH_CURRY,
            allRecipes = testRecipes,
            monthPlans = plans
        )

        assertTrue("Change must succeed", changeResult is ChangeResult.Success)
        val updatedPlan = (changeResult as ChangeResult.Success).updatedPlan

        // Verify Curry changed
        assertNotEquals(originalCurryId, updatedPlan.lunchCurryRecipeId)
        assertNotNull(updatedPlan.lunchCurryRecipeName)

        // Verify Rice, Fry, Breakfast, Dinner remain UNCHANGED!
        assertEquals(originalRiceId, updatedPlan.lunchRiceRecipeId)
        assertEquals(originalFryId, updatedPlan.lunchFryRecipeId)
        assertEquals(originalBreakfastId, updatedPlan.breakfastRecipeId)
        assertEquals(originalDinnerId, updatedPlan.dinnerRecipeId)
    }

    @Test
    fun `test Change button on Sunday lunch preserves Biryani rule`() {
        val plans = MealPlanningEngine.generateMonthPlan(2026, 10, testRecipes)
        val sundayPlan = plans.first { it.dayOfWeek == "SUNDAY" }

        val changeResult = MealPlanningEngine.changeMeal(
            currentPlan = sundayPlan,
            slot = MealSlot.LUNCH_BIRYANI,
            allRecipes = testRecipes,
            monthPlans = plans
        )

        assertTrue(changeResult is ChangeResult.Success)
        val updated = (changeResult as ChangeResult.Success).updatedPlan

        assertEquals("BIRYANI", updated.lunchType)
        assertNotEquals(sundayPlan.lunchBiryaniRecipeId, updated.lunchBiryaniRecipeId)
        assertTrue(
            updated.lunchBiryaniRecipeName == "Veg Biryani" || updated.lunchBiryaniRecipeName == "Paneer Biryani"
        )
    }

    @Test
    fun `test Change button when no alternatives available returns NoAlternatives`() {
        // Only one recipe in Breakfast collection
        val singleBreakfastRecipeList = listOf(
            Recipe(id = 100L, name = "Solo Dosa", url = "https://pin/solo", collectionName = "Chilla / Dosa / Paratha")
        )

        val plan = DailyMealPlan(
            yearMonth = "2026-10",
            dateIso = "2026-10-12",
            dayOfMonth = 12,
            dayOfWeek = "MONDAY",
            breakfastRecipeId = 100L,
            breakfastRecipeName = "Solo Dosa",
            breakfastRecipeUrl = "https://pin/solo"
        )

        val changeResult = MealPlanningEngine.changeMeal(
            currentPlan = plan,
            slot = MealSlot.BREAKFAST,
            allRecipes = singleBreakfastRecipeList,
            monthPlans = listOf(plan)
        )

        assertTrue(changeResult is ChangeResult.NoAlternatives)
        val noAlt = changeResult as ChangeResult.NoAlternatives
        assertEquals("No alternative recipes available. Add more recipes to this collection.", noAlt.message)
    }
}
