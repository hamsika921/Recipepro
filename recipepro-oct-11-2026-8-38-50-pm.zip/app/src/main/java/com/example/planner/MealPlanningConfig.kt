package com.example.planner

/**
 * Centralized, configurable meal planning rules and collections.
 * You can modify these collections, mappings, and keywords as requirements evolve.
 */
object MealPlanningConfig {

    // Predefined 21 collections in specified order
    val PREDEFINED_COLLECTIONS = listOf(
        "Chilla / Dosa / Paratha",
        "Rice",
        "Biryani",
        "Pasta",
        "Sandwiches / Burgers",
        "Tacos / Shawarma",
        "Fry",
        "Curry",
        "Chips / Potato Rolls",
        "Pizza",
        "Cookies / Biscuits",
        "Soup",
        "Cakes",
        "Momo / Punugulu / Bajji",
        "Bread",
        "Noodles",
        "Mixtures",
        "Chocolate",
        "Pancakes",
        "Dips",
        "Chutney"
    )

    // Rule 7: Sunday-only collections (can appear ONLY on Sundays)
    val SUNDAY_ONLY_COLLECTIONS = setOf(
        "Bread",
        "Mixtures",
        "Cakes",
        "Cookies / Biscuits",
        "Chocolate"
    )

    // Rule 1: Breakfast collections
    // Note: "Bread" is only eligible if day is Sunday (enforced by rule engine)
    val BREAKFAST_COLLECTIONS = setOf(
        "Chilla / Dosa / Paratha",
        "Pancakes",
        "Bread"
    )

    // Rule 2: Lunch components
    val LUNCH_RICE_COLLECTIONS = setOf("Rice")
    val LUNCH_CURRY_COLLECTIONS = setOf("Curry")
    val LUNCH_FRY_COLLECTIONS = setOf("Fry")

    // Rule 5: Sunday lunch collection
    val SUNDAY_LUNCH_COLLECTIONS = setOf("Biryani")

    // Rule 4: Evening snack collections
    // (Sunday-only collections will be added dynamically when day is Sunday)
    val BASE_SNACK_COLLECTIONS = setOf(
        "Momo / Punugulu / Bajji",
        "Chips / Potato Rolls",
        "Sandwiches / Burgers",
        "Tacos / Shawarma",
        "Noodles",
        "Soup",
        "Pasta",
        "Dips",
        "Chutney"
    )

    // Rule 3: Dinner collections
    val DINNER_COLLECTIONS = setOf(
        "Chilla / Dosa / Paratha",
        "Pasta",
        "Sandwiches / Burgers",
        "Tacos / Shawarma",
        "Pizza",
        "Noodles",
        "Soup"
    )

    // Rule 8: Exclude Chicken collections
    val EXCLUDED_COLLECTION_KEYWORDS = setOf(
        "chicken"
    )

    // Rule 9: Exclude drinks, juices, ice cream
    val EXCLUDED_FOOD_KEYWORDS = setOf(
        "drink", "drinks", "juice", "juices", "ice cream", "icecream", "smoothie", "cocktail", "mocktail"
    )

    // Rule 6: Saturday Vegetarian check keywords (non-veg indicators)
    val NON_VEGETARIAN_KEYWORDS = setOf(
        "chicken", "mutton", "fish", "prawn", "prawns", "egg", "eggs", "meat", "beef", "pork",
        "keema", "bacon", "salmon", "shrimp", "shrimps", "crab", "ham", "turkey", "lamb", "duck", "sausage"
    )

    /**
     * Checks if a recipe is excluded by Rule 8 (Chicken) or Rule 9 (drinks/juices/ice cream).
     */
    fun isRecipeGloballyExcluded(collectionName: String, recipeName: String): Boolean {
        val colLower = collectionName.lowercase()
        val nameLower = recipeName.lowercase()

        // Rule 8: Chicken collection check
        if (EXCLUDED_COLLECTION_KEYWORDS.any { colLower.contains(it) }) return true

        // Rule 9: Excluded foods check
        if (EXCLUDED_FOOD_KEYWORDS.any { colLower.contains(it) || nameLower.contains(it) }) return true

        return false
    }

    /**
     * Checks if recipe satisfies Saturday Vegetarian rule (Rule 6).
     */
    fun isVegetarian(collectionName: String, recipeName: String): Boolean {
        val colLower = collectionName.lowercase()
        val nameLower = recipeName.lowercase()

        return !NON_VEGETARIAN_KEYWORDS.any { kw ->
            colLower.contains(kw) || nameLower.contains(kw)
        }
    }
}
