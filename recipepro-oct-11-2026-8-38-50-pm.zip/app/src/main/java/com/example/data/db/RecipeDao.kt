package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Recipe
import kotlinx.coroutines.flow.Flow

@Dao
interface RecipeDao {

    @Query("SELECT * FROM recipes ORDER BY name ASC")
    fun getAllRecipes(): Flow<List<Recipe>>

    @Query("SELECT * FROM recipes ORDER BY name ASC")
    suspend fun getAllRecipesSnapshot(): List<Recipe>

    @Query("SELECT * FROM recipes WHERE collectionName = :collection ORDER BY name ASC")
    fun getRecipesByCollection(collection: String): Flow<List<Recipe>>

    @Query("SELECT * FROM recipes WHERE collectionName = :collection ORDER BY name ASC")
    suspend fun getRecipesByCollectionSnapshot(collection: String): List<Recipe>

    @Query("SELECT * FROM recipes WHERE id = :id LIMIT 1")
    suspend fun getRecipeById(id: Long): Recipe?

    @Query("SELECT * FROM recipes WHERE name LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchRecipes(query: String): Flow<List<Recipe>>

    @Query("SELECT COUNT(*) FROM recipes WHERE collectionName = :collection AND LOWER(name) = LOWER(:name) AND (:excludeId IS NULL OR id != :excludeId)")
    suspend fun countDuplicateName(collection: String, name: String, excludeId: Long?): Int

    @Query("SELECT COUNT(*) FROM recipes")
    suspend fun getRecipeCount(): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertRecipe(recipe: Recipe): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecipes(recipes: List<Recipe>): List<Long>

    @Update
    suspend fun updateRecipe(recipe: Recipe)

    @Delete
    suspend fun deleteRecipe(recipe: Recipe)

    @Query("DELETE FROM recipes WHERE id = :id")
    suspend fun deleteRecipeById(id: Long)
}
