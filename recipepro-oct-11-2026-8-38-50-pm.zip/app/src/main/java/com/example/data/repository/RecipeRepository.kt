package com.example.data.repository

import com.example.data.db.MealPlanDao
import com.example.data.db.RecipeDao
import com.example.data.model.DailyMealPlan
import com.example.data.model.Recipe
import com.example.planner.ChangeResult
import com.example.planner.MealPlanningConfig
import com.example.planner.MealPlanningEngine
import com.example.planner.MealSlot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.Locale

class RecipeRepository(
    private val recipeDao: RecipeDao,
    private val mealPlanDao: MealPlanDao
) {

    val allRecipes: Flow<List<Recipe>> = recipeDao.getAllRecipes()

    fun getRecipesByCollection(collection: String): Flow<List<Recipe>> =
        recipeDao.getRecipesByCollection(collection)

    fun searchRecipes(query: String): Flow<List<Recipe>> =
        recipeDao.searchRecipes(query.trim())

    fun getMonthPlans(yearMonth: String): Flow<List<DailyMealPlan>> =
        mealPlanDao.getMonthPlans(yearMonth)

    fun getDayPlan(dateIso: String): Flow<DailyMealPlan?> =
        mealPlanDao.getDayPlan(dateIso)

    /**
     * Seeds initial collections and recipes if database is empty.
     */
    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val count = recipeDao.getRecipeCount()
        if (count == 0) {
            val starterRecipes = listOf(
                // 1. Chilla / Dosa / Paratha
                Recipe(name = "Crispy Masala Dosa", url = "https://www.pinterest.com/pin/crispy-masala-dosa-recipe/", collectionName = "Chilla / Dosa / Paratha"),
                Recipe(name = "Moong Dal Chilla", url = "https://www.instagram.com/p/moong-dal-chilla-healthy/", collectionName = "Chilla / Dosa / Paratha"),
                Recipe(name = "Stuffed Aloo Paratha", url = "https://www.pinterest.com/pin/stuffed-aloo-paratha-dhaba/", collectionName = "Chilla / Dosa / Paratha"),
                Recipe(name = "Methi Thepla", url = "https://www.instagram.com/p/gujarati-methi-thepla/", collectionName = "Chilla / Dosa / Paratha"),

                // 2. Rice
                Recipe(name = "Jeera Rice", url = "https://www.pinterest.com/pin/restaurant-jeera-rice-easy/", collectionName = "Rice"),
                Recipe(name = "Ghee Rice", url = "https://www.instagram.com/p/aromatic-kerala-ghee-rice/", collectionName = "Rice"),
                Recipe(name = "Steamed Basmati Rice", url = "https://www.pinterest.com/pin/how-to-cook-perfect-basmati-rice/", collectionName = "Rice"),
                Recipe(name = "South Indian Curd Rice", url = "https://www.instagram.com/p/tempered-curd-rice-thayir-sadam/", collectionName = "Rice"),

                // 3. Biryani
                Recipe(name = "Hyderabadi Veg Dum Biryani", url = "https://www.pinterest.com/pin/hyderabadi-veg-dum-biryani/", collectionName = "Biryani"),
                Recipe(name = "Paneer Tikka Biryani", url = "https://www.instagram.com/p/paneer-tikka-biryani-pot/", collectionName = "Biryani"),
                Recipe(name = "Mushroom Dum Biryani", url = "https://www.pinterest.com/pin/fragrant-mushroom-biryani/", collectionName = "Biryani"),
                Recipe(name = "Kathal Jackfruit Biryani", url = "https://www.instagram.com/p/awadhi-kathal-biryani/", collectionName = "Biryani"),

                // 4. Pasta
                Recipe(name = "Penne Arrabbiata", url = "https://www.pinterest.com/pin/spicy-penne-arrabbiata-sauce/", collectionName = "Pasta"),
                Recipe(name = "Creamy White Sauce Pasta", url = "https://www.instagram.com/p/creamy-alfredo-garlic-pasta/", collectionName = "Pasta"),
                Recipe(name = "Basil Pesto Spaghetti", url = "https://www.pinterest.com/pin/fresh-basil-pesto-spaghetti/", collectionName = "Pasta"),

                // 5. Sandwiches / Burgers
                Recipe(name = "Bombay Veg Grilled Sandwich", url = "https://www.instagram.com/p/bombay-street-grilled-sandwich/", collectionName = "Sandwiches / Burgers"),
                Recipe(name = "Crispy Paneer Burger", url = "https://www.pinterest.com/pin/crispy-paneer-burger-spicy/", collectionName = "Sandwiches / Burgers"),
                Recipe(name = "Spicy Aloo Tikki Burger", url = "https://www.instagram.com/p/aloo-tikki-burger-mcd-style/", collectionName = "Sandwiches / Burgers"),

                // 6. Tacos / Shawarma
                Recipe(name = "Spiced Paneer Tacos", url = "https://www.pinterest.com/pin/mexican-indian-paneer-tacos/", collectionName = "Tacos / Shawarma"),
                Recipe(name = "Falafel Shawarma Roll", url = "https://www.instagram.com/p/crispy-falafel-wrap-tahini/", collectionName = "Tacos / Shawarma"),

                // 7. Fry
                Recipe(name = "Crispy Aloo Fry", url = "https://www.pinterest.com/pin/south-indian-crispy-potato-fry/", collectionName = "Fry"),
                Recipe(name = "Kurkuri Bhindi Fry", url = "https://www.instagram.com/p/crispy-spiced-bhindi-okra-fry/", collectionName = "Fry"),
                Recipe(name = "Paneer 65 Fry", url = "https://www.pinterest.com/pin/restaurant-style-paneer-65/", collectionName = "Fry"),
                Recipe(name = "Gobi Pepper Fry", url = "https://www.instagram.com/p/cauliflower-pepper-roast-fry/", collectionName = "Fry"),

                // 8. Curry
                Recipe(name = "Paneer Butter Masala", url = "https://www.pinterest.com/pin/rich-paneer-butter-masala-gravy/", collectionName = "Curry"),
                Recipe(name = "Dhaba Dal Tadka", url = "https://www.instagram.com/p/smoky-dhaba-style-dal-tadka/", collectionName = "Curry"),
                Recipe(name = "Amritsari Chole", url = "https://www.pinterest.com/pin/authentic-amritsari-pindi-chole/", collectionName = "Curry"),
                Recipe(name = "Hotel Veg Kurma", url = "https://www.instagram.com/p/south-indian-vegetable-korma/", collectionName = "Curry"),

                // 9. Chips / Potato Rolls
                Recipe(name = "Crispy Potato Chips", url = "https://www.pinterest.com/pin/homemade-crispy-salted-potato-chips/", collectionName = "Chips / Potato Rolls"),
                Recipe(name = "Potato Bread Rolls", url = "https://www.instagram.com/p/crunchy-potato-bread-roll-snack/", collectionName = "Chips / Potato Rolls"),

                // 10. Pizza
                Recipe(name = "Classic Margherita Pizza", url = "https://www.pinterest.com/pin/authentic-neapolitan-margherita-pizza/", collectionName = "Pizza"),
                Recipe(name = "Farmhouse Veggie Pizza", url = "https://www.instagram.com/p/loaded-veggie-farmhouse-pizza/", collectionName = "Pizza"),

                // 11. Cookies / Biscuits (Sunday only item)
                Recipe(name = "Traditional Nankhatai Biscuits", url = "https://www.pinterest.com/pin/cardamom-nankhatai-cookies/", collectionName = "Cookies / Biscuits"),
                Recipe(name = "Choco Chip Cookies", url = "https://www.instagram.com/p/bakery-style-choco-chip-cookies/", collectionName = "Cookies / Biscuits"),

                // 12. Soup
                Recipe(name = "Roasted Tomato Basil Soup", url = "https://www.pinterest.com/pin/creamy-roasted-tomato-basil-soup/", collectionName = "Soup"),
                Recipe(name = "Sweet Corn Veg Soup", url = "https://www.instagram.com/p/indo-chinese-sweet-corn-soup/", collectionName = "Soup"),

                // 13. Cakes (Sunday only item)
                Recipe(name = "Eggless Moist Chocolate Cake", url = "https://www.pinterest.com/pin/eggless-chocolate-fudge-cake/", collectionName = "Cakes"),
                Recipe(name = "Spiced Carrot Walnut Cake", url = "https://www.instagram.com/p/homemade-carrot-walnut-tea-cake/", collectionName = "Cakes"),

                // 14. Momo / Punugulu / Bajji
                Recipe(name = "Steamed Veg Momos", url = "https://www.pinterest.com/pin/steamed-tibetan-veg-momos-recipe/", collectionName = "Momo / Punugulu / Bajji"),
                Recipe(name = "Street Style Punugulu", url = "https://www.instagram.com/p/andhra-crispy-punugulu-chutney/", collectionName = "Momo / Punugulu / Bajji"),
                Recipe(name = "Crispy Mirchi Bajji", url = "https://www.pinterest.com/pin/stuffed-hyderabadi-mirchi-bajji/", collectionName = "Momo / Punugulu / Bajji"),

                // 15. Bread (Sunday only item)
                Recipe(name = "Garlic Herb Pull-Apart Bread", url = "https://www.pinterest.com/pin/garlic-butter-pull-apart-bread/", collectionName = "Bread"),
                Recipe(name = "Rosemary Sea Salt Focaccia", url = "https://www.instagram.com/p/crispy-golden-olive-focaccia/", collectionName = "Bread"),

                // 16. Noodles
                Recipe(name = "Veg Hakka Noodles", url = "https://www.pinterest.com/pin/street-style-veg-hakka-noodles/", collectionName = "Noodles"),
                Recipe(name = "Spicy Schezwan Noodles", url = "https://www.instagram.com/p/spicy-schezwan-garlic-noodles/", collectionName = "Noodles"),

                // 17. Mixtures (Sunday only item)
                Recipe(name = "South Indian Corn Mixture", url = "https://www.pinterest.com/pin/crispy-spicy-corn-mixture-snack/", collectionName = "Mixtures"),
                Recipe(name = "Roasted Poha Chivda", url = "https://www.instagram.com/p/maharashtrian-poha-chivda-snack/", collectionName = "Mixtures"),

                // 18. Chocolate (Sunday only item)
                Recipe(name = "Dark Chocolate Walnut Fudge", url = "https://www.pinterest.com/pin/rich-dark-chocolate-walnut-fudge/", collectionName = "Chocolate"),
                Recipe(name = "Handmade Almond Truffles", url = "https://www.instagram.com/p/cocoa-dusted-almond-truffles/", collectionName = "Chocolate"),

                // 19. Pancakes
                Recipe(name = "Classic Fluffy Pancakes", url = "https://www.pinterest.com/pin/easy-fluffy-breakfast-pancakes/", collectionName = "Pancakes"),
                Recipe(name = "Banana Oat Pancakes", url = "https://www.instagram.com/p/healthy-banana-oatmeal-pancakes/", collectionName = "Pancakes"),

                // 20. Dips
                Recipe(name = "Authentic Creamy Hummus", url = "https://www.pinterest.com/pin/velvety-garlic-creamy-hummus/", collectionName = "Dips"),
                Recipe(name = "Garlic Herb Greek Yogurt Dip", url = "https://www.instagram.com/p/healthy-garlic-herb-yogurt-dip/", collectionName = "Dips"),

                // 21. Chutney
                Recipe(name = "Coconut Chutney", url = "https://www.pinterest.com/pin/south-indian-hotel-coconut-chutney/", collectionName = "Chutney"),
                Recipe(name = "Mint Coriander Chutney", url = "https://www.instagram.com/p/vibrant-spicy-green-chutney/", collectionName = "Chutney")
            )
            recipeDao.insertRecipes(starterRecipes)
        }
    }

    /**
     * Adds a recipe with validation and duplicate prevention.
     */
    suspend fun addRecipe(name: String, url: String, collectionName: String): Result<Long> = withContext(Dispatchers.IO) {
        val cleanName = name.trim()
        val cleanUrl = url.trim()
        val cleanCol = collectionName.trim()

        if (cleanName.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe name is required."))
        }
        if (cleanUrl.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe URL is required."))
        }
        if (cleanCol.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Please select a collection."))
        }

        // Validate URL format
        val normalizedUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            "https://$cleanUrl"
        } else {
            cleanUrl
        }

        // Duplicate check within same collection
        val duplicateCount = recipeDao.countDuplicateName(cleanCol, cleanName, null)
        if (duplicateCount > 0) {
            return@withContext Result.failure(
                IllegalArgumentException("A recipe named '$cleanName' already exists in the '$cleanCol' collection.")
            )
        }

        try {
            val id = recipeDao.insertRecipe(
                Recipe(
                    name = cleanName,
                    url = normalizedUrl,
                    collectionName = cleanCol
                )
            )
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Updates an existing recipe with validation and duplicate prevention.
     */
    suspend fun updateRecipe(recipe: Recipe): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanName = recipe.name.trim()
        val cleanUrl = recipe.url.trim()
        val cleanCol = recipe.collectionName.trim()

        if (cleanName.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe name cannot be blank."))
        }
        if (cleanUrl.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Recipe URL cannot be blank."))
        }

        val normalizedUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            "https://$cleanUrl"
        } else {
            cleanUrl
        }

        val duplicateCount = recipeDao.countDuplicateName(cleanCol, cleanName, recipe.id)
        if (duplicateCount > 0) {
            return@withContext Result.failure(
                IllegalArgumentException("Another recipe named '$cleanName' already exists in '$cleanCol'.")
            )
        }

        try {
            recipeDao.updateRecipe(recipe.copy(name = cleanName, url = normalizedUrl, collectionName = cleanCol))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteRecipe(recipeId: Long) = withContext(Dispatchers.IO) {
        recipeDao.deleteRecipeById(recipeId)
    }

    /**
     * Ensures the monthly meal plan exists in the database.
     * If not already generated, automatically generates and persists it.
     */
    suspend fun ensureMonthPlanGenerated(year: Int, month: Int) = withContext(Dispatchers.IO) {
        val yearMonthStr = String.format(Locale.US, "%04d-%02d", year, month)
        val existingCount = mealPlanDao.countMonthPlans(yearMonthStr)
        if (existingCount == 0) {
            val all = recipeDao.getAllRecipesSnapshot()
            val plans = MealPlanningEngine.generateMonthPlan(year, month, all)
            mealPlanDao.insertPlans(plans)
        }
    }

    /**
     * Explicitly regenerates the meal plan for a month.
     */
    suspend fun regenerateMonthPlan(year: Int, month: Int) = withContext(Dispatchers.IO) {
        val yearMonthStr = String.format(Locale.US, "%04d-%02d", year, month)
        mealPlanDao.deleteMonthPlans(yearMonthStr)
        val all = recipeDao.getAllRecipesSnapshot()
        val plans = MealPlanningEngine.generateMonthPlan(year, month, all)
        mealPlanDao.insertPlans(plans)
    }

    /**
     * Executes the Change button action for a single meal or lunch component.
     * Updates only that slot, saves permanently to database, and returns the result.
     */
    suspend fun changeMeal(
        plan: DailyMealPlan,
        slot: MealSlot,
        forcedReplacement: Recipe? = null
    ): ChangeResult = withContext(Dispatchers.IO) {
        val allRecipes = recipeDao.getAllRecipesSnapshot()
        val monthPlans = mealPlanDao.getMonthPlansSnapshot(plan.yearMonth)

        val result = MealPlanningEngine.changeMeal(
            currentPlan = plan,
            slot = slot,
            allRecipes = allRecipes,
            monthPlans = monthPlans,
            forcedReplacementRecipe = forcedReplacement
        )

        if (result is ChangeResult.Success) {
            // Save change permanently to database immediately
            mealPlanDao.insertOrUpdatePlan(result.updatedPlan)
        }

        result
    }

    /**
     * Retrieves all alternative eligible candidates for a slot.
     */
    suspend fun getEligibleAlternatives(
        plan: DailyMealPlan,
        slot: MealSlot
    ): List<Recipe> = withContext(Dispatchers.IO) {
        val allRecipes = recipeDao.getAllRecipesSnapshot()
        val monthPlans = mealPlanDao.getMonthPlansSnapshot(plan.yearMonth)
        val isSunday = plan.dayOfWeek.equals("SUNDAY", ignoreCase = true)
        val isSaturday = plan.dayOfWeek.equals("SATURDAY", ignoreCase = true)

        val currentRecipeId = when (slot) {
            MealSlot.BREAKFAST -> plan.breakfastRecipeId
            MealSlot.LUNCH_RICE -> plan.lunchRiceRecipeId
            MealSlot.LUNCH_CURRY -> plan.lunchCurryRecipeId
            MealSlot.LUNCH_FRY -> plan.lunchFryRecipeId
            MealSlot.LUNCH_BIRYANI -> plan.lunchBiryaniRecipeId
            MealSlot.SNACK -> plan.snackRecipeId
            MealSlot.DINNER -> plan.dinnerRecipeId
        }

        MealPlanningEngine.getEligibleAlternatives(
            slot = slot,
            recipes = allRecipes,
            isSunday = isSunday,
            isSaturday = isSaturday,
            currentRecipeId = currentRecipeId,
            monthPlans = monthPlans
        )
    }
}
