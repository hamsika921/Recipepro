package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ForestGreenLight,
    onPrimary = Color(0xFF042109),
    primaryContainer = Color(0xFF1E4224),
    onPrimaryContainer = SageGreenContainer,
    secondary = SageGreenLight,
    onSecondary = Color(0xFF142416),
    secondaryContainer = Color(0xFF2C4331),
    onSecondaryContainer = OliveSecondaryContainer,
    tertiary = WarmTerracottaContainer,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    outline = Color(0xFF6B7A6E),
    outlineVariant = Color(0xFF38453A)
)

private val LightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,
    onPrimary = ForestGreenOnPrimary,
    primaryContainer = SageGreenContainer,
    onPrimaryContainer = SageGreenOnContainer,
    secondary = OliveSecondary,
    onSecondary = Color.White,
    secondaryContainer = OliveSecondaryContainer,
    onSecondaryContainer = OliveOnSecondaryContainer,
    tertiary = WarmTerracotta,
    onTertiary = Color.White,
    tertiaryContainer = WarmTerracottaContainer,
    onTertiaryContainer = WarmTerracottaOnContainer,
    background = CreamBackground,
    onBackground = Color(0xFF1E241E),
    surface = CreamSurface,
    onSurface = Color(0xFF1E241E),
    surfaceVariant = CreamSurfaceVariant,
    onSurfaceVariant = Color(0xFF4C554D),
    outline = OutlineWarm,
    outlineVariant = OutlineWarmVariant
)

@Composable
fun RecipeProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep warm culinary aesthetic consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
