package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm cream and sage green culinary palette
val CreamBackground = Color(0xFFFAF7F2)
val CreamSurface = Color(0xFFFFFDFB)
val CreamSurfaceVariant = Color(0xFFF2EBE0)
val OutlineWarm = Color(0xFFD5CEBF)
val OutlineWarmVariant = Color(0xFFE6E1D8)

val ForestGreenPrimary = Color(0xFF285430)
val ForestGreenOnPrimary = Color(0xFFFFFFFF)
val SageGreenContainer = Color(0xFFD8EAD7)
val SageGreenOnContainer = Color(0xFF0F2E14)

val OliveSecondary = Color(0xFF4B6651)
val OliveSecondaryContainer = Color(0xFFDEE9DF)
val OliveOnSecondaryContainer = Color(0xFF132A17)

val WarmTerracotta = Color(0xFF8A5630)
val WarmTerracottaContainer = Color(0xFFF5DFC9)
val WarmTerracottaOnContainer = Color(0xFF381E0A)

val DarkBackground = Color(0xFF141914)
val DarkSurface = Color(0xFF1A211B)
val DarkSurfaceVariant = Color(0xFF242E25)
val ForestGreenLight = Color(0xFF8FD89B)
val SageGreenLight = Color(0xFFB0D3B5)
