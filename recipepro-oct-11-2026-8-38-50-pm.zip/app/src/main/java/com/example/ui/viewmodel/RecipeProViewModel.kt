package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.DailyMealPlan
import com.example.data.model.Recipe
import com.example.data.repository.RecipeRepository
import com.example.planner.ChangeResult
import com.example.planner.MealPlanningConfig
import com.example.planner.MealSlot
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

enum class ScreenTab {
    HOME,
    PLANNER,
    COLLECTIONS,
    ADD_RECIPE
}

data class SlotPickerState(
    val plan: DailyMealPlan,
    val slot: MealSlot,
    val alternatives: List<Recipe>
)

class RecipeProViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RecipeRepository

    // Calendar initialization (starts with current date, e.g. Oct 2026)
    private val calendar = Calendar.getInstance()
    private val initialYear = calendar.get(Calendar.YEAR)
    private val initialMonth = calendar.get(Calendar.MONTH) + 1 // 1..12
    private val initialDay = calendar.get(Calendar.DAY_OF_MONTH)

    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    private val _selectedYear = MutableStateFlow(initialYear)
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _selectedMonth = MutableStateFlow(initialMonth)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedDay = MutableStateFlow(initialDay)
    val selectedDay: StateFlow<Int> = _selectedDay.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCollectionFilter = MutableStateFlow<String?>(null)
    val selectedCollectionFilter: StateFlow<String?> = _selectedCollectionFilter.asStateFlow()

    private val _slotPickerState = MutableStateFlow<SlotPickerState?>(null)
    val slotPickerState: StateFlow<SlotPickerState?> = _slotPickerState.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    val allRecipes: StateFlow<List<Recipe>>

    val filteredRecipes: StateFlow<List<Recipe>>

    val currentMonthPlans: StateFlow<List<DailyMealPlan>>

    val todayPlan: StateFlow<DailyMealPlan?>

    init {
        val database = AppDatabase.getDatabase(application)
        repository = RecipeRepository(database.recipeDao(), database.mealPlanDao())

        allRecipes = repository.allRecipes.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredRecipes = combine(allRecipes, _searchQuery, _selectedCollectionFilter) { list, query, col ->
            var result = list
            if (!col.isNullOrBlank()) {
                result = result.filter { it.collectionName == col }
            }
            if (query.isNotBlank()) {
                result = result.filter { it.name.contains(query, ignoreCase = true) }
            }
            result
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Observe month plans dynamically for the selected year and month
        currentMonthPlans = combine(_selectedYear, _selectedMonth) { year, month ->
            String.format(Locale.US, "%04d-%02d", year, month)
        }.flatMapLatest { yearMonth ->
            repository.getMonthPlans(yearMonth)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Today's plan
        val todayIso = String.format(Locale.US, "%04d-%02d-%02d", initialYear, initialMonth, initialDay)
        todayPlan = repository.getDayPlan(todayIso).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

        // Seed initial recipes if empty, then ensure current month plan is generated
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
            repository.ensureMonthPlanGenerated(initialYear, initialMonth)
        }
    }

    fun setTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCollectionFilter(collection: String?) {
        _selectedCollectionFilter.value = collection
    }

    fun selectDay(day: Int) {
        _selectedDay.value = day
    }

    fun previousMonth() {
        var y = _selectedYear.value
        var m = _selectedMonth.value - 1
        if (m < 1) {
            m = 12
            y -= 1
        }
        _selectedYear.value = y
        _selectedMonth.value = m
        _selectedDay.value = 1
        viewModelScope.launch {
            repository.ensureMonthPlanGenerated(y, m)
        }
    }

    fun nextMonth() {
        var y = _selectedYear.value
        var m = _selectedMonth.value + 1
        if (m > 12) {
            m = 1
            y += 1
        }
        _selectedYear.value = y
        _selectedMonth.value = m
        _selectedDay.value = 1
        viewModelScope.launch {
            repository.ensureMonthPlanGenerated(y, m)
        }
    }

    fun goToCurrentMonth() {
        _selectedYear.value = initialYear
        _selectedMonth.value = initialMonth
        _selectedDay.value = initialDay
        viewModelScope.launch {
            repository.ensureMonthPlanGenerated(initialYear, initialMonth)
        }
    }

    fun regenerateCurrentMonth() {
        viewModelScope.launch {
            repository.regenerateMonthPlan(_selectedYear.value, _selectedMonth.value)
            _userMessage.emit("Regenerated meal plan for ${getMonthName(_selectedMonth.value)} ${_selectedYear.value}.")
        }
    }

    /**
     * Critical Change Button action:
     * Replaces only the specified meal slot in the daily plan.
     * Keeps all other meals unchanged, preserves rules, updates immediately and persists to Room DB.
     */
    fun onSlotChangeClicked(plan: DailyMealPlan, slot: MealSlot) {
        viewModelScope.launch {
            val result = repository.changeMeal(plan, slot)
            when (result) {
                is ChangeResult.Success -> {
                    _userMessage.emit("${slot.displayName} changed to '${result.newRecipeName}'.")
                }
                is ChangeResult.NoAlternatives -> {
                    _userMessage.emit(result.message)
                }
            }
        }
    }

    /**
     * Opens modal/picker to manually choose from all eligible alternatives.
     */
    fun openSlotAlternativePicker(plan: DailyMealPlan, slot: MealSlot) {
        viewModelScope.launch {
            val alternatives = repository.getEligibleAlternatives(plan, slot)
            if (alternatives.isEmpty()) {
                _userMessage.emit("No alternative recipes available. Add more recipes to this collection.")
            } else {
                _slotPickerState.value = SlotPickerState(plan, slot, alternatives)
            }
        }
    }

    fun closeSlotAlternativePicker() {
        _slotPickerState.value = null
    }

    fun applySpecificAlternative(recipe: Recipe) {
        val picker = _slotPickerState.value ?: return
        viewModelScope.launch {
            val result = repository.changeMeal(picker.plan, picker.slot, forcedReplacement = recipe)
            if (result is ChangeResult.Success) {
                _userMessage.emit("${picker.slot.displayName} changed to '${recipe.name}'.")
            }
            _slotPickerState.value = null
        }
    }

    /**
     * Add recipe with validation & duplicate prevention.
     */
    fun addRecipe(name: String, url: String, collectionName: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = repository.addRecipe(name, url, collectionName)
            if (result.isSuccess) {
                _userMessage.emit("Recipe '$name' saved to $collectionName!")
                onDone(true)
            } else {
                _userMessage.emit(result.exceptionOrNull()?.message ?: "Failed to save recipe.")
                onDone(false)
            }
        }
    }

    /**
     * Update recipe with validation & duplicate prevention.
     */
    fun updateRecipe(recipe: Recipe, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = repository.updateRecipe(recipe)
            if (result.isSuccess) {
                _userMessage.emit("Recipe '${recipe.name}' updated!")
                onDone(true)
            } else {
                _userMessage.emit(result.exceptionOrNull()?.message ?: "Failed to update recipe.")
                onDone(false)
            }
        }
    }

    fun deleteRecipe(recipe: Recipe) {
        viewModelScope.launch {
            repository.deleteRecipe(recipe.id)
            _userMessage.emit("Deleted '${recipe.name}'.")
        }
    }

    fun getMonthName(month: Int): String {
        return when (month) {
            1 -> "January"
            2 -> "February"
            3 -> "March"
            4 -> "April"
            5 -> "May"
            6 -> "June"
            7 -> "July"
            8 -> "August"
            9 -> "September"
            10 -> "October"
            11 -> "November"
            12 -> "December"
            else -> "Month $month"
        }
    }
}
